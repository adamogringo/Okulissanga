import axios from 'axios';
import {Component} from 'react';
import {ReactSession} from 'react-client-session';
import { 
	redirect, Outlet 
} from 'react-router-dom';
import config from '../lib/config';
import Apps from './partials/Apps';
import Docs from './partials/Ebooks';
import Music from './partials/Audios';
import Pictures from './partials/Pictures';
import Videos from './partials/Videos';
import Others from './partials/Others.jsx'
import Footer from './partials/Footer';
//import Nav from './partials/nav';
import Header from './partials/Header';
import ResearchForm from './partials/Research-Form';
import '../css/home.css';
import SelectLanguage from './partials/SelectLanguage';

//Take care cookie
ReactSession.setStoreType('cookie');

export async function loader({params}){
  //recover the params from URL and make request 
  //for check existence of user current
  const idUser = params.idUser;
  try{
    // Making the requisition 
    const result = await axios.post(`/accounts/users/${idUser}/check_id`);
    //console.log('home.jsx ***', result,ReactSession.get("_id") === idUser);
    if(result.status === 200 && ReactSession.get("_id") === idUser){
      return null;
    }else{
      return redirect('/404');  
    }
  }catch(e){
    config.error('E: *** /home/:idUser', e);
    return redirect('/404');
  }
}

class Home extends Component{
    constructor(props){
        super(props);
        this.state = {
            apps: null, docs: null, music:null, 
            pictures: null, videos:null, others: null,
            next:0,
        };
        
    }

    componentDidMount(){
      // Loading sections        
      this.loadApps();
      this.loadDocs();
      this.loadMusic();
      this.loadPictures();
      this.loadVideos();
      this.loadOthers();
    }

    loadApps(){
      fetch('/api/apps')
          .then(response => response.json())
          .then(data => {
              this.setState({apps: data});
          })
          .catch(err => {
              console.error('E: ***', err);
          });
    }

    loadDocs(){
      fetch('/api/docs')
          .then(response => response.json())
          .then(data => {
              this.setState({docs: data});
          })
          .catch(err => {
              console.error('E: ***', err);
          });
    }

    loadMusic(){
      fetch('/api/audios')
          .then(response => response.json())
          .then(data => {
              this.setState({music: data});
          })
          .catch(err => {
              console.error('E: ***', err);
          });
    }
    loadPictures(){
      fetch('/api/pictures')
          .then(response => response.json())
          .then(data => {
              this.setState({pictures: data});
          })
          .catch(err => {
              console.error('E: ***', err);
          });
    }
    loadVideos(){
        fetch('/api/videos')
            .then(response => response.json())
            .then(data => {
                this.setState({videos: data});
            })
            .catch(err => {
                console.error('E: ***', err);
            });
    } 
    loadOthers(){
        fetch('/api/others')
            .then(response => response.json())
            .then(data => {
                this.setState({others: data});
            })
            .catch(err => {
                console.error('E: ***', err);
            });
    }
    
    render(){
        return(
          <div id="home-container">
              <Header>
                <div className='header-node-children'>
                  <SelectLanguage className='research-form'/>
                  <ResearchForm id='research-form'/>
                </div>
              </Header>
              <div id="container-main">
                {/* <Nav /> */}
                <Outlet />
                <div className="main">
                    <section className="apps" id="apps">
                        <Apps datas={this.state.apps} next={this.state.next}/>
                    </section>
                    <section className="docs" id="docs">
                        <Docs datas={this.state.docs} next={this.state.next} />
                    </section>
                    <section className="music" id="music">
                        <Music datas={this.state.music} next={this.state.next} />
                    </section>
                    <section className="pictures" id="pictures">
                        <Pictures datas={this.state.pictures} next={this.state.next} />
                    </section>
                    <section className="videos" id="videos" >
                        <Videos datas={this.state.videos} next={this.state.next} />
                    </section>
                    <section className="others" id="others">
                        <Others datas={this.state.others} next={this.state.next}/>
                    </section>
                </div>
              </div>
                <Footer/>
          </div>
        );
    }
}

export default Home;

