import axios from 'axios';
import { ReactSession } from 'react-client-session';
import React, {Component} from 'react';
import {
    Form,
    Link,
    redirect,
} from 'react-router-dom'
import Footer from './partials/Footer';
import Header from './partials/Header';
import config from '../lib/config';
import '../css/signin.css';

export async function loader(){
  //Verify by client-session
  const idUser = ReactSession.get('_id') ? ReactSession.get('_id') : '';
  if(idUser){
    return redirect(`/home/${idUser}`);
  }
  return null; 
}

export async function action({request, params}){
    const formData = await request.formData();
    const userDatas = Object.fromEntries(formData);
    //VERIFY LOGIN
    //email -> email || phone-number; clean all space that exists
    userDatas.email = userDatas.email.replace(/\s+/g,'');
    if(!config.verifyLogin(userDatas.email)){
      let msg;
        if(ReactSession.get('lang') === 'pt'){
          msg = 'Email or número de telefone inválido!';
          document.querySelector('#feedback-sigin').innerHTML = msg;
        }else{
          msg = 'Email or phone number invalid!';
          document.querySelector('#feedback-sigin').innerHTML = msg;
        }
        return null;
    }
    //config.log('credentials SENDING for LOGIN', userDatas);
    try{
      const response = await axios.post(
        `/accounts/signin`,
        userDatas
        );
        if(response.status === 200){
          //Save the '_id', 'status' on COOKIE and redirect for /home/ID page
          ReactSession.set('_id', response.data._id);
          ReactSession.set('status', response.data.status);
          return redirect(`/home/${response.data._id}`);
        }
    }catch(e){
      config.error('signin.jsx; action() error', e.response);
      if(e.response.status === 404){
        let msg;
        if(ReactSession.get('lang') === 'pt'){
          msg = 'Usuário ou palavra-passe incorreto!';
          document.querySelector('#feedback-sigin').innerHTML = msg;
        }else{
          msg = 'User or password incorrect!';
          document.querySelector('#feedback-sigin').innerHTML = msg;
        }
        return null;
      }else{
        //Handler others avalaible code from server
        return redirect('/signin?status=user not found');
      }
    }
}

/* *************************************
  Main-Class as Route
 ************************************* */
export default class SignIn extends Component{
  renderContent(){
    switch(ReactSession.get('lang')){
      default:
        return(
          <div id='signin-container'>
            <Header />
            <div id="signin-container-main">
              <div id="feedback-sigin" className='feedback-invalid'></div>
              <div id="signin-form">
                  <Form method='POST'>
                    <fieldset>
                      <legend>User login</legend>
                      <input type='text' placeholder='Email or Phone-number' name='email' required /> <br/>
                      <input type='password' placeholder='Password' name='password' required/> <br/>
                      <div className="go_to_sign">
                        <button className='go_to_sign_controlsBtn'>Login</button>
                        <Link to="/signup" className='go_to_sign_controlsBtn'>Signup</Link>
                      </div>
                    </fieldset>
                  </Form>
              </div>
            </div>
            <Footer />
          </div>
      );

      case 'pt':
        return(
          <div id='signin-container'>
            <Header />
            <div id="signin-container-main">
            <div id="feedback-sigin" className='feedback-invalid'></div>
            <div id="signin-form">
                <Form method='POST'>
                  <fieldset>
                    <legend>Iniciar Sessão</legend>
                    <input type='text' placeholder='Email ou número de telefone' name='email' required /> <br/>
                    <input type='Password' placeholder='Senha' name='password' required /> <br/>
                    <div className="go_to_sign">
                      <button className='go_to_sign_controlsBtn'>Entrar</button>
                      <Link to="/signup" className='go_to_sign_controlsBtn'>Criar uma nova conta</Link>
                    </div>
                  </fieldset>
                </Form>
            </div>
            </div>
            <Footer />
          </div>
      );
    }
  }  
  
  render(){
        return this.renderContent();
    }
}