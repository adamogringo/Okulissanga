import { ReactSession } from 'react-client-session';
import {  
  redirect
} from 'react-router-dom';
import config from "../lib/config";

//Take care session client
ReactSession.setStoreType('cookie');

export async function loader(){
  const idUser = ReactSession.get('_id') ? ReactSession.get('_id') : '';
  if(idUser){
    return redirect(`/home/${idUser}`);
  }
  return redirect('/');
}

export default function IndexHome(){
  console.log('IndexHome:', config.session.user);
  return(
    <p>Just pass by here without display nothing, might read 
      the session or cookie for redirect to user</p>
  );
}