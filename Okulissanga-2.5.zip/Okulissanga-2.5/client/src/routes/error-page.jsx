import { ReactSession } from 'react-client-session';
import { useRouteError, Link } from 'react-router-dom';
//import config from '../lib/config';
import '../css/error-page.css';


export default function ErrorPage(){
    const error = useRouteError();
    // Using the regex for find the valid URL if else assign the root '/'
    let url = error.data.match(/"(\/.+\/)/) && error.data.match(/"(\/.+\/)/)[1];
    console.error(error);
    
    switch(ReactSession.get('lang')){
      default:
        return(
          <div id="error-page-container">
              <h1>Oops!</h1>
              <p>Sorry, an unexpected error has occurred.</p>
              <p>
                  <i>{error.statusText || error.message}</i>
              </p>
              <h3>Invalid URL!</h3>
              <p><Link to={url}>Came back</Link></p>
              <p><Link to='/'>Home</Link></p>
          </div>
      );

    case 'pt':    // The same thing above, but in other language
      return(
        <div id="error-page-container">
            <h1>Oops!</h1>
            <p>Desculpa!, algum erro inesperado aconteceu.</p>
            <p>
                <i>{error.statusText || error.message}</i>
            </p>
            <h3>URL inválida!</h3>
            <p><Link to={url}>Voltar</Link></p>
            <p><Link to='/'>Página inicial</Link></p>
        </div>
    );
    }
}