// import React, {Component} from 'react';
// import {redirect} from 'react-router-dom';

// export async function loader({params}){
//   config.log('LOGIN, LOGIN, LOGIN')
//     //recover the params from URL and make request 
//     //for check existence of user current
//     let idUser = params.idUser;
//     return (
//         fetch(`/accounts/login/${idUser}`)
//             .then(response => response.json())
//             .then(response => {
//                 if(response.ok){
//                     console.log('H:LOGIN',response);
//                     return redirect(`/home/${response.data[0]._id}`);
//                 }else{
//                     return redirect(`/signin?user=not exist`);
//                 }
                
//             })
//             .catch(error => {
//                 console.log('E:***', error);
//                 return null;
//             })
//     );
// }

// export default class Login extends Component{
  
// }