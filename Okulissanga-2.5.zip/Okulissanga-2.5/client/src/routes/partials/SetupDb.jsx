import axios from 'axios';
import { ReactSession } from 'react-client-session';
import { useState } from 'react';
import config from '../../lib/config';

let msg = ReactSession.get('lang') === 'pt' 
        ? 'Favor em preencher a senha do administrador "correta" para afetuar a ação pretendida!' 
        : 'Please, fill the password field "correct", for finish the action wanted!'

const listFeedback = {
  'Load-DB':  'Loading... to DB ' + new Date(),
  'Reset-DB': 'Reseting... DB ' + new Date(),
  'msg': msg
}

export function SetupDb(props){
  let [feedback, setFeedback] = useState('');
  const handleOnClick  = async(e) => {
    e.preventDefault();
    let formData = new FormData();
    formData.append('adminPassword', props.adminPassword);
    formData = Object.fromEntries(formData);
    //config.log('SetupDb.jsx', e.target, formData.adminPassword);
    if(!formData.adminPassword){
      alert(listFeedback['msg']);
      return null;
    }
    //config.log('SENDING to',props.url, formData);
    try{
      //Make request for server
      let response = await axios.post(
        props.url,
        formData);
      if(response.status===200){
        setFeedback(props.action);
        console.log(response);
      }
    }catch(e){
      setFeedback('msg');
      config.error('SetupDb.jsx',e.response);
    }
  }
  //config.log('SetupDb.jsx;', props);
  return(
    <section className='action'>
      <h2> {props.title} </h2>
      <p> {props.desc} </p>
      <button type='submit'
        onClick={handleOnClick} className={props.className}> 
        {props.action} 
      </button>
      <section id="feedback">
        <h5>{listFeedback[feedback]}</h5>
      </section>
    </section>
  );
}
