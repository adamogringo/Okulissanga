import axios from 'axios';
import React, {useState} from 'react';
import {ReactSession} from 'react-client-session';
import {
  useLoaderData,
} from 'react-router-dom';
import config from '../../lib/config';
import Footer from './Footer';
import Header from './Header';
import ItemsResearched from './ItemsResearched';
import {
  MinApps, MinDocs, MinAudios, 
  MinPictures, MinOthers , MinVideos
} from './Custom';
import ResearchForm from './Research-Form';
import '../../css/partials/search.css';

export async function loader({request}){
  // Applying the regular expressions for find the research
  // by client and keep safe the extraction and decodeURI
  let q = request.url.match(config.re_q) ? request.url.match(config.re_q)[1] : '';
  q = decodeURI(q);
  if(config.operators.split(';').filter(op => q.indexOf(op) !== -1).length){
    // Like q.split('+').join(' ').split('-').join(' ').split('*').join(' ').split('/').join(' ');
    for(let i in config.operators){
      q = q.split(config.operators[i]).join(' ');
    }
  }
  
  try{
    let response = await axios.get(`/files/search/${q}`)
    if(response.status === 200){
      //config.log('Search.jsx; RECEIVED', response)
      //Return the research made by user  + response.data
      return {q, data:response.data}
    }
    
  }catch(e){
    config.error('Search.jsx', e.response);
    //return redirect('/404');
    return null;
  }
}


/* ****************************
    Search - Page
*****************************/
export default function Search(){
  let [totalApps]        = useState(0),
      [totalDocs]        = useState(0),
      [totalAudios]       = useState(0),
      [totalPictures] = useState(0),
      [totalVideos ]    = useState(0),
      [totalOthers]     = useState(0),
      [total] = useState(0);
  let [next, setNext] = useState(0);
  let [category, setCategory] = useState('');

  //Get the return of loader-function
  let datas,
      resultSearch = useLoaderData();
  if(resultSearch){
    datas = resultSearch.data;
  }
      
  let resultApps,
      resultDocs,
      resultAudios,
      resultOthers,
      resultPictures,
      result,
      resultVideos;
  if(datas){
    //Take care the datas-results after client make a research
    // if(Object(datas).status === 404){
    //   datas = []; //Not Found results!
    // }
    // Transform the structure datas for a Component afther check 
    resultApps = datas.filter(file => config.fextname.apps.indexOf(file.fextname) !== -1)
                          .map(file => <MinApps key={file._id} file={file} />);
    resultDocs = datas.filter(file => config.fextname.docs.indexOf(file.fextname) !== -1)
                          .map(file => <MinDocs key={file._id} file={file} />);
    resultAudios = datas.filter(file => config.fextname.audios.indexOf(file.fextname) !== -1)
                          .map(file => <MinAudios key={file._id} file={file} />);
    resultPictures = datas.filter(file => config.fextname.pictures.indexOf(file.fextname) !== -1)
                           .map(file => <MinPictures key={file._id} file={file} />);
    resultVideos = datas.filter(file => config.fextname.videos.indexOf(file.fextname) !== -1)
                         .map(file => <MinVideos key={file._id} file={file} />);
    resultOthers = datas.filter(file => config.fextname.others.indexOf(file.fextname) !== -1)
                            .map(file => <MinOthers key={file._id} file={file} />);
      // Join all list - custom, mix the result
      result = [...resultApps, ...resultDocs, ...resultAudios, ...resultPictures, 
                ...resultVideos, ...resultOthers];
          totalApps = resultApps.length;
          totalDocs = resultDocs.length;
          totalAudios = resultAudios.length;
          totalPictures = resultPictures.length;
          totalVideos = resultVideos.length;
          totalOthers = resultOthers.length;
          total = result.length;
      
      // Make slice for result customize
      result = result.slice(next, next + config.amountOnSectionsResearched);
  }
  //INNER-FUNCTIONS HELPERS
  const _handleBtnPrev = (e) => {
    setNext(next - config.amountOnSectionsResearched);
  }
  const _handleBtnNext = (e) => {
    setNext(next + config.amountOnSectionsResearched);
  }
  const onClickHandlerItemsResult = (e) => {
    e.preventDefault();
    //Assign the category, for handler the display 
    //category from research made
    setCategory(e.target.className);    
    //config.log('onClickHandlerItemsResult() *******',e.target, category);
  }//END onClickHandlerItemsResult()

  const renderStatusResult = () => {
    switch(ReactSession.get('lang')){
      default:
        return(
          <div id='status'>
            <div className="status-total" id='total'>
              <span><h2>{total}</h2></span>
              <span>Results Founds about
                <h3><i>{resultSearch && resultSearch.q}</i></h3>
              </span>
            </div>
            <div id="status-items">
              <div onClick={onClickHandlerItemsResult} id='status-apps'>
              <ItemsResearched text='Total Apps' category='Apps'
                status={totalApps} 
                />
            </div>
            <div onClick={onClickHandlerItemsResult} id='status-docs'>
              <ItemsResearched 
                text='Total Docs' category='Docs'
                status={totalDocs} 
                />
            </div>
            <div onClick={onClickHandlerItemsResult} id='status-music'>
              <ItemsResearched 
                text='Total Music' category='Music'
                status={totalAudios} 
                />
            </div>
            <div onClick={onClickHandlerItemsResult} id='status-pictures'>
              <ItemsResearched 
                text='Total Pictures' category='Pictures'
                status={totalPictures} 
                />
            </div>
            <div id='status-videos' onClick={onClickHandlerItemsResult}>
              <ItemsResearched 
                text='Total Videos' category='Videos'
                status={totalVideos} 
                />
            </div>
            <div onClick={onClickHandlerItemsResult} id='status-others'>
              <ItemsResearched 
                text='Total Others' category='Others'
                status={totalOthers} 
                />
            </div>
          </div>
        </div>
      );
      case 'pt':
        return(
          <div id='status'>
            <div className="status-total" id='total'>
              <span><h2>{total}</h2></span>
              <span>Resultados encontrados acerca de 
                <h3><i>{resultSearch && resultSearch.q}</i></h3>
              </span>
            </div>
            <div id="status-items">
              <div onClick={onClickHandlerItemsResult} id='status-apps'>
              <ItemsResearched text='Total de Aplicativos' category='Apps'
                status={totalApps} 
                />
            </div>
            <div onClick={onClickHandlerItemsResult} id='status-docs'>
              <ItemsResearched 
                text='Total de E-books' category='Docs'
                status={totalDocs} 
                />
            </div>
            <div onClick={onClickHandlerItemsResult} id='status-music'>
              <ItemsResearched 
                text='Total de Aúdios' category='Music'
                status={totalAudios} 
                />
            </div>
            <div onClick={onClickHandlerItemsResult} id='status-pictures'>
              <ItemsResearched 
                text='Total de Imagens' category='Pictures'
                status={totalPictures} 
                />
            </div>
            <div id='status-videos' onClick={onClickHandlerItemsResult}>
              <ItemsResearched 
                text='Total de Vídeos' category='Videos'
                status={totalVideos} 
                />
            </div>
            <div onClick={onClickHandlerItemsResult} id='status-others'>
              <ItemsResearched 
                text='Total de Outros Arquivos' category='Others'
                status={totalOthers} 
                />
            </div>
          </div>
        </div>
      );

    }
  }//END renderStatusResult()

  const renderContent = () => {
    //config.log('Search.jsx; renderContent() category:', category)
    //[SWITCH] the language
    switch(ReactSession.get('lang')){
      default:
        //[SWITCH] the display between items-category
        switch(category){
          default:  
            //Display the className 'list-result-mix'
            return(
              <div id="result-research-main">
                {renderStatusResult()}
                <div id="list-result-mix">
                  <ul>
                    {result}
                  </ul>
                </div>
              <div className="controlsBtn">
                <button className="btnPrev" onClick={_handleBtnPrev}>Previous</button>
                <button className="btnNext" onClick={_handleBtnNext}>Next</button>
              </div>
            </div>
          );
          
          //JUST SHOW THE NODE
          case 'Apps':
            return(
              <div id="apps-category" className='result-research-main'>
                { renderStatusResult() }
                <div  id='status-apps'>
                  <ItemsResearched text='Total Apps' category='Apps'
                    status={totalApps} data={resultApps}
                    onClick={onClickHandlerItemsResult}
                    layoutControls='flex'
                    />
                </div>                  
              </div>
            );
          case 'Docs':
            return(
              <div id="apps-category" className='result-research-main'>
                { renderStatusResult() }
                <div id='status-docs'>
                  <ItemsResearched 
                    text='Total Docs' category='Docs'
                    status={totalDocs} data={resultDocs}
                    onClick={onClickHandlerItemsResult}
                    layoutControls='flex'
                  />
              </div>
            </div>
            );
          case 'Music':
            return(
              <div id="apps-category" className='result-research-main'>
                { renderStatusResult() }
              <div id='status-music'>
                <ItemsResearched 
                  text='Total Music' category='Music'
                  status={totalAudios} data={resultAudios}
                  onClick={onClickHandlerItemsResult}
                  layoutControls='flex'
                  />
              </div>
            </div>
            );
          case 'Pictures':
            return(
              <div id="apps-category" className='result-research-main'>
                { renderStatusResult() }
                <div id='status-pictures'>
                  <ItemsResearched 
                    text='Total Pictures' category='Pictures'
                    status={totalPictures} data={resultPictures}
                    onClick={onClickHandlerItemsResult}
                    layoutControls='flex'
                    />
                </div>
              </div>
            );            
          case 'Videos':
            return(
              <div id="apps-category" className='result-research-main'>
                { renderStatusResult() }
                <div id="apps-category" className='result-research-main'>
                  <div id='status-videos' >
                    <ItemsResearched 
                      text='Total Videos' category='Videos'
                      status={totalVideos} data={resultVideos}
                      onClick={onClickHandlerItemsResult}
                      layoutControls='flex'
                    />
                  </div>
                </div>
          </div>
          );
          case 'Others':
            return(
              <div id="apps-category" className='result-research-main'>
                { renderStatusResult() }
                <div id='status-others'>
                  <ItemsResearched 
                    text='Total Others' category='Others'
                    status={totalOthers} data={resultOthers}
                    onClick={onClickHandlerItemsResult}
                    layoutControls='flex'
                  />
                </div>
              </div>
            );
        }//END switch inner ('category')
    
    case 'pt':  //THE SAME THAT ABOVE, BUT IN OTHER LANGUAGE
      switch(category){
        default:  
          //Display the className 'list-result-mix'
          return(
            <div id="result-research-main">
              {renderStatusResult()}
              <div id="list-result-mix">
                <ul>
                  {result}
                </ul>
              </div>
            <div className="controlsBtn">
              <button className="btnPrev" onClick={_handleBtnPrev}>Anterior</button>
              <button className="btnNext" onClick={_handleBtnNext}>Próximo</button>
            </div>
          </div>
        );
        // JUST SHOW THE NODE SELECTED
        case 'Apps':
          return(
            <div id="apps-category" className='result-research-main'>
              { renderStatusResult() }
              <div  id='status-apps'>
                <ItemsResearched text='Total de Aplicativos' category='Apps'
                  status={totalApps} data={resultApps}
                  onClick={onClickHandlerItemsResult}
                  layoutControls='flex'
                  />
              </div>                  
            </div>
          );
        case 'Docs':
          return(
            <div id="apps-category" className='result-research-main'>
              { renderStatusResult() }
              <div id='status-docs'>
                <ItemsResearched 
                  text='Total de E-books' category='Docs'
                  status={totalDocs} data={resultDocs}
                  onClick={onClickHandlerItemsResult}
                  layoutControls='flex'
                />
            </div>
          </div>
          );
        case 'Music':
          return(
            <div id="apps-category" className='result-research-main'>
              { renderStatusResult() }
            <div id='status-music'>
              <ItemsResearched 
                text='Total de Aúdios' category='Music'
                status={totalAudios} data={resultAudios}
                onClick={onClickHandlerItemsResult}
                layoutControls='flex'
                />
            </div>
          </div>
          );
        case 'Pictures':
          return(
            <div id="apps-category" className='result-research-main'>
              { renderStatusResult() }
              <div id='status-pictures'>
                <ItemsResearched 
                  text='Total de Imagens' category='Pictures'
                  status={totalPictures} data={resultPictures}
                  onClick={onClickHandlerItemsResult}
                  layoutControls='flex'
                  />
              </div>
            </div>
          );            
        case 'Videos':
          return(
            <div id="apps-category" className='result-research-main'>
              { renderStatusResult() }
              <div id="apps-category" className='result-research-main'>
                <div id='status-videos' >
                  <ItemsResearched 
                    text='Total de Vídeos' category='Videos'
                    status={totalVideos} data={resultVideos}
                    onClick={onClickHandlerItemsResult}
                    layoutControls='flex'
                  />
                </div>
              </div>
        </div>
        );
        case 'Others':
          return(
            <div id="apps-category" className='result-research-main'>
              { renderStatusResult() }
              <div id='status-others'>
                <ItemsResearched 
                  text='Total de outros ficheiros' category='Others'
                  status={totalOthers} data={resultOthers}
                  onClick={onClickHandlerItemsResult}
                  layoutControls='flex'
                />
              </div>
            </div>
          );
      }
    }//End SWITCH outer (lang)
  }//END renderContent()
  
  //ABOVE STILL HERE IS LIKE render() FUNCTION
  return(
    <div id='search-container'>
      <Header>
        <div className="header-node-children">
          <ResearchForm />
        </div>
      </Header>
        {renderContent()}
      <Footer />
    </div>
  );
}

