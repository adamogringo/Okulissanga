import React from 'react';
import {ReactSession} from 'react-client-session';
import '../../css/partials/footer.css';

export default class Footer extends React.Component{
  renderContent(){
    switch(ReactSession.get('lang')){
      default:
        return(
          <footer className={this.props.className}>
              <p><a href='/help'>Help</a></p>
              <p>Copyleft @ Okulissanga 2.5</p>
              <p>by Adam O'Gringo</p>
              <p>2022 - 2023</p>
          </footer>
        );
    
      case 'pt':
        return(
          <footer>
              <p><a href='/help'>Ajuda</a></p>
              <p>Copyleft @ Okulissanga 2.5</p>
              <p>por Adam O'gringo</p>
              <p>2022 - 2023</p>
          </footer>
      );
    }
  }
    render(){
        return this.renderContent();
    }
}