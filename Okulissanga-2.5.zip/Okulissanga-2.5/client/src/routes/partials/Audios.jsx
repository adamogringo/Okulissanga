import { ReactSession } from 'react-client-session';
import React from 'react';
import {MinAudios} from './Custom';
import config from '../../lib/config';


/****************************** 
     E-BOOKS - COMPONENT 
* ******************************/
export default class Audios extends React.Component{
    constructor(props){
        super(props);
        this.state = {next: 0, total: 0};
    }

    componentDidMount(){
      if(this.props.datas){
        this.setState({total: this.props.datas.length});
      }
    }

    _handleBtnNextAudios = () => {
        this.setState({next: this.state.next + config.amountOnSections});
    }

    _handleBtnPrevAudios = () => {
        this.setState({next: this.state.next - config.amountOnSections});
    }

    render(){
      let result,
          total = 0;
      if(this.props.datas){
        total = total = this.props.datas.length;
        let datas = this.props.datas.slice(this.state.next, this.state.next + config.amountOnSections);
        result = datas.map(file => <MinAudios key={file._id} file={file} />);
      }

      switch(ReactSession.get('lang')){
        default:
          return(
            <div className="articles">
              <h2>Audios ({this.state.total || total})</h2>
              <ul>{result}</ul>
              <div className="controlsBtn">
                <button className="btnPrev" onClick={this._handleBtnPrevAudios}>Previous</button>
                <button className="btnNext" onClick={this._handleBtnNextAudios}>Next</button>
              </div>
            </div>
          );
          
        case 'pt':
          return(
            <div className="articles">
              <h2>Aúdios ({this.state.total || total})</h2>
              <ul>{result}</ul>
              <div className="controlsBtn">
                <button className="btnPrev" onClick={this._handleBtnPrevAudios}>Anterior</button>
                <button className="btnNext" onClick={this._handleBtnNextAudios}>Próximo</button>
              </div>
            </div>
          );
      }//END switch
    }
}
