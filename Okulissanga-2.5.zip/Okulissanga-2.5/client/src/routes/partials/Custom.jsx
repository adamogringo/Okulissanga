//import { useState } from 'react';
import {
  Link,
} from 'react-router-dom';
import { ReactSession } from 'react-client-session';
import config from '../../lib/config';

// Using on .../users_manager - page in specific
const Row = (props) => {
  let idAdmin = ReactSession.get('_id');
  return(
    <tr>
      <td>
        {/* <a href={`/admin/home/${idAdmin}/users_manager/${props._id}`}>{props._id.substr(0, 10)}</a> */}
        <Link to={`/admin/home/${idAdmin}/users_manager/${props._id}`}>
          {props._id.substr(0, 10)}
        </Link>
      </td>
      <td>{props.name}</td>
      <td>{props.gender}</td>
      <td>{props.email}</td>
      <td>{props.phoneNumber}</td>
      <td>{props.status}</td>
    </tr>
  );
}

// *** MIN-CUSTOM COMPONENT ***
// const MinLiArticle = (props) => (
//     <div className="minComponent">
//         <li>
//             <a href={config.protocol + config.host +':'+ config.portServer 
//               +'/'+ props.file.fpath}>
//                 <img src="" alt={props.file.fextname} />
//                 {props.file.fname}
//             </a>
//         </li>
//     </div>
// );

const MinApps = (props) => {
  switch(ReactSession.get('lang')){
    default:
      return (
        <div className="minComponent">
          <li>
            <img src="../../imgs/apps-example.ico" alt={props.file.fextname} />
              <div className="description">
                <a href={config.protocol + config.host +':'+ config.portServer 
                  +'/'+ props.file.fpath} target='_blank' rel="noreferrer">
                  {props.file.fname}
                </a>
                <p>{config.getSizeParsed(props.file.fsize)}</p>
              </div>
          </li>
        </div>
      );

    case 'pt':    //The same above, but in other language 'PT'
      return (      
        <div className="minComponent">
          <li>
            <img src="../../imgs/apps-example.ico" alt={props.file.fextname} />
              <div className="description">
                <a href={config.protocol + config.host +':'+ config.portServer 
                  +'/'+ props.file.fpath} target='_blank' rel="noreferrer">
                  {props.file.fname}
                </a>
                <p>{config.getSizeParsed(props.file.fsize)}</p>
              </div>
          </li>
        </div>
      );
  }
	
};

const MinDocs = (props) => {
  switch(ReactSession.get('lang')){
    default:
      return(
        <div className="minComponent">
          <li>
              <img src="../../imgs/docs-example.ico" alt={props.file.fextname} />
              <div className="description">
                <a href={config.protocol + config.host +':'+ config.portServer 
                  +'/'+ props.file.fpath} target='_blank' rel="noreferrer">
                    {props.file.fname}
                </a>
                <p>{config.getSizeParsed(props.file.fsize)}</p>
              </div>
          </li>
	      </div>
      );
      
    case 'pt':
      return(
        <div className="minComponent">
          <li>
              <img src="../../imgs/docs-example.ico" alt={props.file.fextname} />
              <div className="description">
                <a href={config.protocol + config.host +':'+ config.portServer 
                  +'/'+ props.file.fpath} target='_blank' rel="noreferrer">
                    {props.file.fname}
                </a>
                <p>{config.getSizeParsed(props.file.fsize)}</p>
              </div>
          </li>
	      </div>
      );
  }
	
};

const MinAudios = (props) => {
  switch(ReactSession.get('lang')){
    default:
      return(
        <div className="minComponent">
          <li>
              <audio src={config.protocol + config.host +':'+ config.portServer +'/'
                + props.file.fpath} controls />
              <div className="description">
                <a href={config.protocol + config.host +':'+ config.portServer +'/'
                  + props.file.fpath} target='_blank' rel="noreferrer">
                    {props.file.fname}
                </a>
                <p>{config.getSizeParsed(props.file.fsize)}</p>
              </div>
          </li>
        </div>
      );

    case 'pt':
      return(
        <div className="minComponent">
          <li>
              <audio src={config.protocol + config.host +':'+ config.portServer +'/'
                + props.file.fpath} controls />
              <div className="description">
                <a href={config.protocol + config.host +':'+ config.portServer +'/'
                  + props.file.fpath} target='_blank' rel="noreferrer">
                    {props.file.fname}
                </a>
                <p>{config.getSizeParsed(props.file.fsize)}</p>
              </div>
          </li>
        </div>
      );
  }
    
};

const MinPictures = (props) => {
  switch(ReactSession.get('lang')){
    default:
      return(    
        <div className="minComponent">
            <li>
                <img src={config.protocol + config.host +':'+ config.portServer 
                  +'/'+ props.file.fpath} alt={props.file.fname} />
                <div className="description">
                    <a href={config.protocol + config.host +':'+ config.portServer +'/'
                      + props.file.fpath} target='_blank' rel="noreferrer">
                        {props.file.fname}
                    </a>
                    <p>{config.getSizeParsed(props.file.fsize)}</p>
                </div>
            </li>
        </div>
      );

    case 'pt':
      return(    
        <div className="minComponent">
            <li>
                <img src={config.protocol + config.host +':'+ config.portServer 
                  +'/'+ props.file.fpath} alt={props.file.fname} />
                <div className="description">
                    <a href={config.protocol + config.host +':'+ config.portServer +'/'
                      + props.file.fpath} target='_blank' rel="noreferrer">
                        {props.file.fname}
                    </a>
                    <p>{config.getSizeParsed(props.file.fsize)}</p>
                </div>
            </li>
        </div>
      );
  }
};

const MinVideos = (props) => {
  switch(ReactSession.get('lang')){
    default:
      return(
        <div className="minComponent">    
            <li>
                <video src={config.protocol + config.host +':'+ config.portServer 
                  +'/'+ props.file.fpath} 
                  controls />
                <div className="description">
                  <a href={config.protocol + config.host +':'+ config.portServer +'/'
                    + props.file.fpath} target='_blank' rel="noreferrer">
                      {props.file.fname}
                  </a>
                  <p>{config.getSizeParsed(props.file.fsize)}</p>
                </div>
            </li>
        </div>
      );

    case 'pt':
      return(
        <div className="minComponent">    
            <li>
                <video src={config.protocol + config.host +':'+ config.portServer 
                  +'/'+ props.file.fpath} 
                  controls />
                <div className="description">
                  <a href={config.protocol + config.host +':'+ config.portServer +'/'
                    + props.file.fpath} target='_blank' rel="noreferrer">
                      {props.file.fname}
                  </a>
                  <p>{config.getSizeParsed(props.file.fsize)}</p>
                </div>
            </li>
        </div>
      );
  }
};

const MinOthers = (props) => {
  switch(ReactSession.get('lang')){
    default:
      return(
        <div className="minComponent">
            <li>
                <img src="../../imgs/others-example.png" alt={props.file.fextname} />
                <div className="description">
                  <a href={config.protocol + config.host +':'+ config.portServer 
                    +'/'+ props.file.fpath} target='_blank' rel="noreferrer">
                      {props.file.fname}
                  </a>
                  <p>{config.getSizeParsed(props.file.fsize)}</p>
                </div>
            </li>
        </div>
      );

    case 'pt':
      return(
        <div className="minComponent">
            <li>
                <img src="../../imgs/others-example.png" alt={props.file.fextname} />
                <div className="description">
                  <a href={config.protocol + config.host +':'+ config.portServer 
                    +'/'+ props.file.fpath} target='_blank' rel="noreferrer">
                      {props.file.fname}
                  </a>
                  <p>{config.getSizeParsed(props.file.fsize)}</p>
                </div>
            </li>
        </div>
      );
  }
};

export {MinApps, MinDocs, MinAudios, MinPictures, MinOthers , MinVideos, Row}