import { ReactSession } from 'react-client-session';
import {
  Form,
} from 'react-router-dom';
import '../../css/partials/research-form.css'

export default function ResearchForm(){
  let idUser = ReactSession.get('_id');
  //Inner-function for help on action-form
  const _handleSearch = (e) => {
    if(e){
      let form = document.forms.fsearch;
      let search = form.q.value;
      return search
    }
  }

  switch(ReactSession.get('lang')){
    default:
      return(
        <div id="research-form-main">
          <Form name="fsearch" action={`/home/${idUser}/search?q=${_handleSearch()}`}>
            <input type="search" name="q" id="searched" 
              placeholder="Search here ..."/>
            <button type="submit">Search</button>
          </Form>
        </div>
      );

    case 'pt':
      return(
        <div id="research-form-main">
          <Form name="fsearch" action={`/home/${idUser}/search?q=${_handleSearch()}`}>
            <input type="search" name="q" id="searched" 
              placeholder="Pesquisa aqui ..."/>
            <button type="submit">Pesquisar</button>
          </Form>
      </div>
      );
  }
}