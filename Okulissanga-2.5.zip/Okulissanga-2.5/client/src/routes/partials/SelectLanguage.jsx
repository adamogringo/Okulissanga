import { useState } from 'react';
import { ReactSession } from 'react-client-session';
import '../../css/partials/select-language.css'

export default function SelectLanguage(){
  const [language, setLanguage] = useState('');

  const onClickLang = (e) => {
    //Take care of language if was be offline 
    //Keep on cookies still logout
    let lang = e.target.value;
    setLanguage(lang);
    ReactSession.set('lang', language);
    //config.log('SelectLanguage.jsx',ReactSession.get('lang'), language);
  }

  switch(ReactSession.get('lang')){
    default:
      return(
        <select name="lang" id="lang" 
          onClick={onClickLang}
          onChange={onClickLang}
          >
          <option value="en" >English</option>
          <option value="pt" >Portuguese</option>
        </select>       
      ); 
    case 'pt':
      return(        
        <select name="lang" id="lang" 
          onClick={onClickLang}
          onChange={onClickLang}
          defaultValue='pt'>
          <option value="en">Inglês</option>
          <option value="pt">Português</option>
        </select>
      );
    }
}