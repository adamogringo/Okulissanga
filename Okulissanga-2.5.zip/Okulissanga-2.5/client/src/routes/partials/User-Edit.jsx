import React, {useState} from 'react';
import {
  Form
} from 'react-router-dom';
import config from '../../lib/config';

export default function UserEdit(){

  config.log('User-Edit.jsx; render()');
  return (
    <div id='user-edit'>
      <Form>
        <p>UserEdit</p>
      </Form>
    </div>
  );
}