import {Component} from 'react';
import { ReactSession } from 'react-client-session';
import {
  Link,
} from 'react-router-dom';
import '../../css/partials/header.css';
//import config from '../../lib/config';

export default class Header extends Component{
  render(){
    //config.log('Header.jsx;',{this.props.children && this.props.children.props});
    //console.log(this.props.children && this.props.children.props);
      let idUser= ReactSession.get("_id") ? ReactSession.get("_id") : "";
        return(
          <header id="main" className={this.props.className}>
            <section id="header">
              <Link to={`/home/${idUser}`}>
                <img src="/imgs/okulissanga-1.5.png" alt="logo okulissanga site" />
              </Link>
            </section>
            <section className='header-node-children-main'>
              {this.props.children}
            </section>
          </header>
        );
    }
}