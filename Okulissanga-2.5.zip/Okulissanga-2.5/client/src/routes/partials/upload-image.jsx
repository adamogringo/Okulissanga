import axios from 'axios';
import { useState } from 'react';
import { ReactSession } from 'react-client-session';
import {
  Form,
  redirect,
  useLoaderData,
} from 'react-router-dom';
import Footer from './Footer';
import Header from './Header';
import ResearchForm from './Research-Form';
import '../../css/partials/upload-image.css';

export async function loader({params}){
  //Check ID user
  let idUser = params.idUser;
  // Request for server
  try{
    let response = await axios.post(`/accounts/users/${idUser}/check_id`)
    return response;
  }catch(e){
    console.error('E:*** upload-image.jsx -> loader()',e);
    return redirect('/404');
  }
}

export default function UploadImage(){
  let response = useLoaderData();
  let idUser = response.data.user._id;
  let [file, setFile] = useState();
  let [description, setDescription] = useState('');

  const submit = async event => {
    event.preventDefault();
    const formData = new FormData();
    formData.append('image', file);
    description = description || Object.fromEntries(formData).image.name;
    formData.append('description', description);
    console.log('UploadImage() -> formData: ', Object.fromEntries(formData));
    let msg;
    try{
        let result = await axios.post(
          `/accounts/users/${idUser}/edit/upload_image`,
          formData,
          {headers:{'Content-Type':'multipart/form-data'}}
        );
        console.log('UploadImage:***', result);
        if(result.status === 200){
          if(ReactSession.get('lang') === 'pt'){
            msg = `Imagem carregada com successo <a href='/users/${idUser}'>Perfil</a>`;
          }else{
            msg = `Uploading with successfully <a href='/users/${idUser}'>Profile</a>`;
          }
          document.querySelector('#feedback-upload-image').innerHTML = msg
          //return redirect(`/home/users/${idUser}`); //DON'T WORK, WHY?
        }
      }catch(e){
        if(ReactSession.get('lang') === 'pt'){
          msg='Erro!, durante o carregamento da imagem de perfil';
        }else{
          msg = 'Error! when uploading image profile';
        }
        document.querySelector('#feedback-upload-image').innerHTML = msg;
        return null;
      }// END- try/catch
  } //End-Function-inner

  switch(ReactSession.get('lang')){
    default:
      return(
        <div id="upload-image-container">
          <Header>
            <ResearchForm />
          </Header>
          <div id="form-upload-image">
            <Form onSubmit={submit}>
              <fieldset>
                <legend>Upload profile image</legend>
                <div id='feedback-upload-image'></div>
                <div id='feedback-upload-image' className='feedback-invalid'></div>
                <input 
                  type='file' 
                  filename={file}
                  accept='image/*'
                  onChange={e => setFile(e.target.files[0])}
                  />
                <textarea 
                  type='text'
                  onChange={e => setDescription(e.target.value)}
                  placeholder="Description (optional)"
                  />
                <button type='submit'>Send</button>
              </fieldset>
            </Form>
          </div>
          <Footer />
        </div>
      );
    
    case 'pt':
      return(
        <div id="upload-image-container">
          <Header />
          <div id="form-upload-image">
            <Form onSubmit={submit}>
              <fieldset>
                <legend>Carregar imagem de perfil</legend>
                <div id='feedback-upload-image'></div>
                <input 
                  type='file' 
                  filename={file}
                  accept='image/*'
                  onChange={e => setFile(e.target.files[0])}
                  />
                <textarea 
                  type='text'
                  onChange={e => setDescription(e.target.value)}
                  placeholder="Descrição (opcional)"
                  />
                <button type='submit'>Enviar</button>
              </fieldset>
            </Form>
          </div>
          <Footer />
        </div>
      );
  }
} 