import {ReactSession} from 'react-client-session';
import React from 'react';
import config from '../../lib/config';
import { MinVideos } from './Custom';

export default class Videos extends React.Component{
    constructor(props){
        super(props);
        this.state = {next: this.props.next, total: 0};
    }

    componentDidMount(){
      if(this.props.datas){
        this.setState({total: this.props.datas.length})
      }
    }

    _handleBtnNextVideos = () => {
        this.setState({next: this.state.next + config.amountOnSections});
    }

		_handleBtnPrevVideos = () => {
			this.setState({next: this.state.next - config.amountOnSections});
		}

    render(){
      let result,
          total = 0;
      if(this.props.datas){
        total = total = this.props.datas.length;
        let datas = this.props.datas.slice(this.state.next, this.state.next + config.amountOnSections);
        result = datas.map(file => <MinVideos key={file._id} file={file}/>)
      }

      switch(ReactSession.get('lang')){
        default:
          return(
              <div>
                  <h2>Videos ({this.state.total || total})</h2>
                  <ul>{result}</ul>
                  <div className="controlsBtn">
                    <button className="btnPrev" onClick={this._handleBtnPrevVideos}>Previous</button>
                    <button className="btnNext" onClick={this._handleBtnNextVideos}>Next</button>
                  </div>
              </div>
          );

        case 'pt':
          return(
            <div>
                <h2>Vídeos ({this.state.total || total})</h2>
                <ul>{result}</ul>
                <div className="controlsBtn">
                  <button className="btnPrev" onClick={this._handleBtnPrevVideos}>Anterior</button>
                  <button className="btnNext" onClick={this._handleBtnNextVideos}>Próximo</button>
                </div>
            </div>
        );
      }//END switch
    }
}
