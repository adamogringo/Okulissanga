import axios from 'axios';
import { ReactSession } from 'react-client-session';
import React from 'react';
import {
  Link,
  redirect,
  useLoaderData,
} from 'react-router-dom';
import config from '../../lib/config';
import '../../css/partials/nav.css';

// Helper functions for routes
export async function loader({params}){
  const idUser = params.idUser;
  try{
    const result = await axios.post(`/accounts/users/${idUser}`);
    return result.data;
  }catch(e){
    config.error('profile.jsx',e);
    return redirect('/404');
  }
}
export async function action(){}

/*** ***********************************
  Nav - COMPONENT/ROUTE 
* ***********************************/
export default function Nav(){  
  const user = useLoaderData();
  //config.log('nav.jsx;', user);
  //RENDER THE CONTENT FOLLOW THE LANGUAGE
  const idUser = ReactSession.get('_id');
  switch(ReactSession.get('lang')){
    default:
      return(
        <div className="nav">                
          <nav>
            <Link className='another-area' to={`/users/${idUser}`} >
              <p id="profile">
                <img alt="user-avatar" 
                  src={`${config.protocol}${config.host}:${config.portServer}/${user.imgProfile}`}/>
              </p>
              <p>Perfil</p>
            </Link>
            <Link id='home' href={`/home/${idUser}`} >Home</Link>
            <a href="#apps">Apps</a>
            <a href="#docs">Docs</a>
            <a href="#music">Music</a>
            <a href="#pictures">Pictures</a>
            <a href="#videos">Videos</a>
            <a href="#others">Others</a>
            {
              ReactSession.get('status')==='admin' 
                ? 
                  <Link className='another-area' to={`/admin/home/${idUser}`}>
                    Management
                  </Link>
                : ''
            }
          </nav>
        </div>
    );

  case 'pt':    // The same thing above, but in other language
    return(
      <div className="nav">
          <nav>
            <Link className='another-area' to={`/users/${idUser}`} >
              <p id="profile">
                <img alt="user-avatar" 
                  src={`${config.protocol}${config.host}:${config.portServer}/${user.imgProfile}`}/>
              </p>
              <p>Perfil</p>
            </Link>
            <Link id='home' href={`/home/${idUser}`} >Página Inicial</Link>
            <a href="#apps">Aplicativos</a>
            <a href="#docs">E-Books</a>
            <a href="#music">Músicas</a>
            <a href="#pictures">Imagens</a>
            <a href="#videos">Vídeos</a>
            <a href="#others">Outros</a>
            {
              ReactSession.get('status')==='admin' 
                ? 
                  <Link className='another-area' to={`/admin/home/${idUser}`}>
                    Gerenciamento
                  </Link>
                : ''
            }
          </nav>
        </div>
    );
  }
}
