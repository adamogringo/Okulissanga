import { ReactSession } from 'react-client-session';
import React from 'react';
import { MinDocs } from './Custom';
import config from '../../lib/config';

/****************************** 
     E-BOOKS - COMPONENT 
* ******************************/
export default class Docs extends React.Component{
    constructor(props){
        super(props);
        this.state = {next: this.props.next, total: 0};
    }

    componentDidMount(){
      if(this.props.datas){
        this.setState({total: this.props.datas.length});
      }
    }

    _handleBtnNextDocs(){
        this.setState({next: this.state.next + config.amountOnSections});
    }

		_handleBtnPrevDocs(){
				this.setState({next: this.state.next - config.amountOnSections});
		}
    
    render(){
        let result,
            total = 0;
        if(this.props.datas){
          total = total = this.props.datas.length;
          let datas = this.props.datas.slice(this.state.next, this.state.next + config.amountOnSections);
          result = datas.map(file => <MinDocs key={file._id} file={file} />);
        }

        switch(ReactSession.get('lang')){
          default:
            return(
                <div>
                    <h2>E-Books ({this.state.total || total})</h2>
                    <ul>{result}</ul>
                    <div className="controlsBtn">
                      <button className="btnPrev" onClick={this._handleBtnPrevDocs}>Previous</button>
                      <button className="btnNext" onClick={this._handleBtnNextDocs}>Next</button>
                    </div>
                </div>
            );

          case 'pt':
            return(
              <div>
                  <h2>E-Books ({this.state.total || total})</h2>
                  <ul>{result}</ul>
                  <div className="controlsBtn">
                    <button className="btnPrev" onClick={this._handleBtnPrevDocs}>Anterior</button>
                    <button className="btnNext" onClick={this._handleBtnNextDocs}>Próximo</button>
                  </div>
              </div>
          );
        }//END switch
    }
}
