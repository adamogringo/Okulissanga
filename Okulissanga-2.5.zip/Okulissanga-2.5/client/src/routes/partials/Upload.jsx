import axios from 'axios';
import { useState } from 'react';
import {
  Form,
} from 'react-router-dom';

export default function Upload(props){
  let url = props.url;
  let [file, setFile] = useState();
  let [description, setDescription] = useState('');

  const formData = new FormData();
  formData.append('file', file);
  description = description || Object.fromEntries(formData).file.name;
  formData.append('description', description);
  formData.append('owner', 'GHOST');
  
  // Function handler for request from server
  let handleSubmit = async (e) => {
    e.preventDefault();
    console.log('UPLOADING...', Object.fromEntries(formData));

    try{
      let result = await axios.post(
        url,
        formData,
        {headers:{'Content-Type':'multipart/form-data'}}
      );
      if(result.status === 200){
        alert('UPLOAD with success!')
      }
    }catch(e){
      console.error('Upload.jsx;', e.response);
    }
  }// End-Function
  
  return (
    <div className="Upload"> 
      <Form method='POST' encType="multipart/form-data" onSubmit={handleSubmit}>
        <input 
          type='file'
          name="filename"
          onChange={(e) => setFile(e.target.files[0])}
          />
        <input 
          type="text" 
          name="description"
          placeholder='description'
          onChange={(e) => setDescription(e.target.value)}
          />
          <button type="submit">Upload</button>
      </Form>
    </div>
  );
}