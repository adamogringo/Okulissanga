import { useState } from "react";
import { ReactSession } from 'react-client-session';
import config from "../../lib/config";

//Like a category result on research (APPS, AUDIOS, E-BOOKS...)
export default function ItemsResearched(props){
  //config.log('props.data', props.data)
  const [next, setNext] = useState(0);
  //Inner-Function helper
  const _handleBtnPrev = (e) => {
    setNext(next - config.amountOnSectionsResearched);
  }

  const _handleBtnNext = (e) => {
    setNext(next + config.amountOnSectionsResearched);
  }

  //Before render the content make the slice on result
  let result;
  if(props.data){
    result = props.data.slice(next, next + config.amountOnSectionsResearched);
  }
  //config.log('PROPAGATION????',next, props.data && props.data.length, 'layout',props.layoutControls);
  switch(ReactSession.get('lang')){
    default:
      return(
        <div id='items-researched-container'>
          <div id="items-status-total">
            <span>
              <a href={`#${props.category}`} className={props.category}>
                {props.status} {props.text}
              </a>
            </span>
          </div>
          <div 
            id={props.category}  
            className='items-researched-main' 
            >
            {result}
          </div>
          <div className='controlsBtn' id='controls-items-researched' 
            style={{display: props.layoutControls || 'none'}}>
            <button className={props.category} id={props.category} onClick={_handleBtnPrev}>Previous</button>
            <button className={props.category} onClick={_handleBtnNext} id={props.category}>Next</button>
          </div>
        </div>
      );
    
    case 'pt':
      return(
        <div id='items-researched-container'>
          <div id="items-status-total">
            <span>
              <a href={`#${props.category}`} className={props.category}>
                {props.status} {props.text}
              </a>
            </span>
          </div>
          <div 
            id={props.category}  
            className='items-researched-main' 
            >
            {result}
          </div>
          <div className='controlsBtn' id='controls-items-researched' 
            style={{display: props.layoutControls || 'none'}}>
            <button className={props.category} id={props.category} 
              onClick={_handleBtnPrev}>
                Anterior
            </button>
            <button className={props.category} id={props.category}
              onClick={_handleBtnNext}>
              Próximo
            </button>
          </div>
        </div>
      );
  }
}
