import {ReactSession} from 'react-client-session';
import React from 'react';
import { MinPictures } from './Custom';
import config from '../../lib/config';

/*** Pictures - COMPONENT ***/
export default class Pictures extends React.Component{
    constructor(props){
        super(props);
        this.state = {next: this.props.next, total: 0};
    }
    
    componentDidMount(){
      if(this.props.datas){
        this.setState({total: this.props.datas.length});
      }
    }

    _handleBtnNextPictures = () => {
        this.setState({next: this.state.next + config.amountOnSections});
    }

		_handleBtnPrevPictures = () => {
			this.setState({next: this.state.next - config.amountOnSections});
		}

    render(){
      let result,
          total = 0;
      if(this.props.datas){
        total = this.props.datas.length;
        let datas = this.props.datas.slice(this.state.next, this.state.next + config.amountOnSections);
        result = datas.map(file => <MinPictures key={file._id} file={file} />);
      }

      switch(ReactSession.get('lang')){
        default:
          return(
              <div>
                  <h2>Pictures ({this.state.total || total})</h2>
                  <ul>{result}</ul>
                  <div className="controlsBtn">
                    <button className="btnPrev" onClick={this._handleBtnPrevPictures}>Previous</button>
                    <button className="btnNext" onClick={this._handleBtnNextPictures}>Next</button>
                  </div>
              </div>
          );

        case 'pt':
          return(
            <div>
                <h2>Imagens ({this.state.total || total})</h2>
                <ul>{result}</ul>
                <div className="controlsBtn">
                  <button className="btnPrev" onClick={this._handleBtnPrevPictures}>Anterior</button>
                  <button className="btnNext" onClick={this._handleBtnNextPictures}>Próximo</button>
                </div>
            </div>
          );
        }//END switch
    }
}
