import axios from 'axios';
import { ReactSession } from 'react-client-session';
import React from 'react';
import {
  Form,
  Link,
  redirect,
  useLoaderData,
}from 'react-router-dom';
import '../../css/users/edit-user.css';
import config from '../../lib/config';

export async function loader({params}){
  //await getUserById(params.idUser)
  const idUser = params.idUser;
  try{
    const response = await axios.post(`/accounts/users/${idUser}`);
    if(response.status === 200){
      return response;
    }else{
      return redirect('404');
    }
  }catch(e){
    config.error('edit-user.jsx', e);
    return redirect('404');
  }
}

export async function action({request, params}){
  // Recover the data presents on form
  // and send for server -> db by POST method
  const formData = await request.formData();
  const userDatas = Object.fromEntries(formData);
  //Verify the password entering by client
  if(!config.verifyPassword(userDatas.password, userDatas.password_v)){
    let msg =  ReactSession.get('lang') === 'pt' 
              ? 'Palavra-passe não combinam' :
                'Password not match!';
    alert(msg);
    return null;  //Avoid send for server
  }
  // Update the password in case the definition a new
  userDatas.password = userDatas.password || userDatas.password_current;

  config.log(userDatas.birthday, userDatas.birthday_new, userDatas);
  // Update the birthday in case the definition a new
  userDatas.birthday = userDatas.birthday_new || userDatas.birthday;
  //Verify the birthday (the date) entering by client
  if(!config.verifyBirthDay(userDatas.birthday)){
    let msg =  ReactSession.get('lang') === 'pt' 
              ? 'Verifica sua idade deves ter no mínimo >= 15 anos!' :
                'Check your age, must have >= 15 anos';
    alert(msg);            
    return null;  //Avoid send for server
  }
  //if OK, finally send for SERVER
  let url =`/accounts/users/${params.idUser}/edit`;
  //let result = await setUser(url, userDatas);
  try{
    let msg;
    await axios.post(url, userDatas);
    if(ReactSession.get('lang') === 'pt'){
      msg = 'Alteração dos dados enviada com sucesso!'
    }else{
      msg = 'Datas alteration send with Successfully!';
    }
    document.querySelector('#feedback-user-edit').innerHTML = msg
  }catch(e){
    alert('Error, Not change!');
  }
  return null;
}

export default function EditUser(){ 
  const result = useLoaderData();
  const user = result.data;

  switch(ReactSession.get('lang')){
    default:
      return(
        <div id="form-edit-user">
          <h2>Edit your perfil</h2>
          <p>
            <Link to={`/users/${user._id}/edit/upload_image`}>Upload profile image</Link>
          </p>
          <Form method='POST'>
            <fieldset>
              <legend>Edit profile</legend>
              <span>ID</span>
              <input type="text" name='_id' defaultValue={user._id} readOnly/>
              <span>Name</span>
              <input type="text" name='name' defaultValue={user.name} required/>
              <span>Email</span>
              <input type='email' name='email' defaultValue={user.email} required/>
              <span>PhoneNumber</span>
              <input type='tel' name='phoneNumber' defaultValue={user.phoneNumber} required/>
              <span>Password (Current)</span>
              <input type="password" name='password_current' required/>
              <span>Password (New)</span>
              <input type="password" name='password'/>
              <span>Password (Confirm New)</span>
              <input type="password" name='password_v'/>
              <span>Gender</span><br/>
              <select name='gender' defaultValue={user.gender}>
                <option value="Female">Female</option>
                <option value="Male">Male</option>
                <option value="Other">Other</option>
              </select> <br/>
              <span>Location (Country - Province - Street)</span>
              <input type="text" name='location' defaultValue={user.location} />
              <span>Jobs, Work</span>
              <input type='text' name='jobs' defaultValue={user.jobs}/><br/>
              <span>Birthday</span>
              <input type="text"  name='birthday' readOnly
                defaultValue={new Date(user.birthday).toDateString()}/><br/>
              <span>Modify Birthday</span>
              <input type="date"  name='birthday_new'/><br/>
              <div id="feedback-user-edit" className='feedback-sucess'></div>
              <button type='submit'>Save</button>
            </fieldset>
          </Form>
        </div>
      );   

    case 'pt':    // The same thing above, but in other language
      return(
        <div id="form-edit-user">
          <h2>Edita seu perfil</h2>
          <p>
            <Link to={`/users/${user._id}/edit/upload_image`}>Carregar imagem de perfil</Link>
          </p>
          <Form method='POST'>
            <span>ID</span>
            <input type="text" name='_id' defaultValue={user._id} readOnly/>
            <span>Nome</span>
            <input type="text" name='name' defaultValue={user.name} required/>
            <span>Email</span>
            <input type='email' name='email' defaultValue={user.email} required/>
            <span>Número de Telefone</span>
            <input type='tel' name='phoneNumber' defaultValue={user.phoneNumber} required/>
            <span>Senha (Atual)</span>
            <input type="password" name='password_current' required/>
            <span>Nova Senha</span>
            <input type="password" name='password'/>
            <span>Confirmar Nova Senha</span>
            <input type="password" name='password_v'/>
            <br/>
            <select name='gender' defaultValue={user.gender}>
              <option value="Feminino">Feminino</option>
              <option value="Masculino">Masculino</option>
              <option value="Outro">Outro</option>
            </select><span>Género</span>
            <br/><br/>
            <span className='small'>Localização (país, província, cidade)</span>
            <input type="text" name='location' defaultValue={user.location} />
            <span>Ocupação, Trabalho</span>
            <input type='text' name='jobs' defaultValue={user.jobs}/><br/>
            <span>Data de Nascimento</span>
            <input type="text"  name='birthday' readOnly
              defaultValue={new Date(user.birthday).toDateString()}/><br/>
            <span>Modificar Data de Nascimento</span>
            <input type="date"  name='birthday_new'/>
            <br/>
            <div id="feedback-user-edit" className='feedback-sucess'></div>
          <button type='submit'>Salvar</button>
          </Form>
        </div>
      );   
  }

  
}