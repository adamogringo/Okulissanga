import { ReactSession } from 'react-client-session';
import {redirect} from 'react-router-dom';
import config from '../../lib/config';

export async function loader(){
  config.log(' *** logout... cleaning datas... ***')
  //Clean datas on session
  ReactSession.remove('_id');
  if(ReactSession.get('status')==='admin'){
    return redirect('/admin');
  }else{
    return redirect('/');
  }
}

export default function Logout(){
  return null;
}