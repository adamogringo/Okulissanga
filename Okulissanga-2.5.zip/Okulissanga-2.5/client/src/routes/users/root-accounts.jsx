/*
  * Route like parent for CRUD each account like 
  * a Manager-PERFIL
*/
import axios from 'axios';
import React, {Component} from 'react';
import {ReactSession} from 'react-client-session';
import {
    Link,
    Outlet,
    redirect,
} from 'react-router-dom';
import Header from '../partials/Header';
import config from '../../lib/config';
import Footer from '../partials/Footer';
import '../../css/users/root-accounts.css';
import ResearchForm from '../partials/Research-Form';

export async function loader({params}){
    const idUser = params.idUser;
    try{
      // Making the requisition 
      const result = await axios.post(`/accounts/users/${idUser}`);
      // Make verification about idUser && login (already make)
      if( result.status === 200 && ReactSession.get('_id') === idUser){
        config.session.user = result.data;
        return null;
      }else{
        return redirect('/404');
      }
    }catch(e){
      config.error(e);
      return redirect('/404');
    }
}

/* ******************************
  Root-Accounts(User) - Page
****************************** */
export default class RootAccounts extends Component{
    constructor(props){
        super(props);
        this.state = {user:{}};
        this.state.user = {
            _id: null,
            name: null,
            email:null,
            gender:null,
        }
    }

    componentDidMount(){
        let user = config.session.user;
        this.setState({user: user});
    }

    render(){
      //Take care of NAV Home: 
      //For status=='users' -> /home/:idUser
      //For status=='admin' -> /admin/home/:idAdmin
      const idUser = ReactSession.get('_id') ? ReactSession.get('_id') : '';
      let urlHome = `/home/${idUser}`;
      if(this.state.user.status === 'admin'){
        urlHome = `/admin/home/${idUser}`
      }

      switch(ReactSession.get('lang')){
        default:
          return(
            <div id='root-accounts-container'>
              <Header>
                <div className='header-node-children'>
                  <ResearchForm />
                </div>
              </Header>
              <div id="root-accounts-main">
                  <section id="manager">
                      <Link to={urlHome}>Home</Link>
                      <Link to={`/users/${idUser}`}>Perfil</Link>
                      <Link to="/users/idUser/chat">Chat</Link>
                      <Link to="/logout">Logout</Link>
                  </section>
                  <section className="nested-routes">
                      <Outlet/>
                  </section>
              </div>
              <Footer />
            </div>
          );
        
        case 'pt':
          return(
            <div id='root-accounts-container'>
              <Header>
                <div className='header-node-children'>
                  <ResearchForm />
                </div>
              </Header>
              <div id="root-accounts-main">
                  <section id="manager">
                    <Link to={urlHome}>Página Principal</Link>
                    <Link to={`/users/${idUser}`}>Perfil</Link>
                    <Link to="/users/idUser/chat">Chat (Bate-Papo)</Link>
                    <Link to="/logout">Terminar Sessão</Link>
                  </section>
                  <section className="nested-routes">
                    <Outlet/>
                  </section>
              </div>
              <Footer />
            </div>
          );

      }
        
    }
}