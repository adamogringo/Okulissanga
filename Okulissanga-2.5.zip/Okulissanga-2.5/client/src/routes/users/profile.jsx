import axios from 'axios';
import {ReactSession} from 'react-client-session';
import {
  Form,
  redirect,
  useLoaderData
} from 'react-router-dom';
import config from "../../lib/config";
import '../../css/users/profile.css';

export async function loader({params}){
  const idUser = params.idUser;
  try{
    const result = await axios.post(`/accounts/users/${idUser}`);
    return result.data;
  }catch(e){
    config.error('profile.jsx',e);
    return redirect('/404');
  }
}

export default function UserPerfil(){
  const user = useLoaderData();
  
  switch(ReactSession.get('lang')){
    default:
      return(
        <div id="profile">
          <p>
            <a href={`${config.protocol}${config.host}:${config.portServer}/${user.imgProfile}`}>
              <img src={`${config.protocol}${config.host}:${config.portServer}/${user.imgProfile}`} 
                alt="user-avatar" />
            </a>
          </p>
          <p>{user.name}</p>
          <p>{user.email}</p>
          <p>{user.jobs}</p>
          <Form action='edit'>
            <button type='submit'>Edit Profile</button>
          </Form>
        </div>
        
      );
    
    case 'pt':    // The same thing, but in other language
      return(
        <div id="profile">
          <p>
            <a href={`${config.protocol}${config.host}:${config.portServer}/${user.imgProfile}`}>
              <img src={`${config.protocol}${config.host}:${config.portServer}/${user.imgProfile}`} 
                alt="user-avatar" />
            </a>
          </p>
          <p>{user.name}</p>
          <p>{user.email}</p>
          <Form action='edit'>
            <button type='submit'>Editar Profile</button>
          </Form>
        </div>
      );
  }

  
}
