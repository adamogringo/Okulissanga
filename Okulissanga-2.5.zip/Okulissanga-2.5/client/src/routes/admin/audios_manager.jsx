import { useState } from 'react';
import {
  Form,
} from 'react-router-dom'
import { ReactSession } from 'react-client-session';
import { SetupDb } from "../partials/SetupDb";

const idAdmin = ReactSession.get('_id') ? ReactSession.get('_id') : '';
// Take care of language
let sections  = null;
switch(ReactSession.get('lang')){
  case 'pt':
    sections = [
      {
        id:1, title:'Carregar Base-Dados', action:'Carregar-DB', 
        desc:`Quando este butão é clicado, o servidor entra em serviço
          e faz uma pesquisa recursiva catagolando os aplicativos para a 
          base de dados e finalmente disponibiliza os mesmos no site .`, 
        url:`/accounts/admin/${idAdmin}/load_db/music`,
        className:'load_db',
      },
      {
        id:2, title:'Limpar a Base de Dados', action:'Limpar-BD', 
        desc:`Quando este butão é clicado, o servidor conectado à base de dados
          remove todos os ficheiros, deixando o site vázio.`, 
        url:`/accounts/admin/${idAdmin}/reset_db/music`,
        className:'reset_db',
      },
    ];     
    break;
    
  default:
    sections = [
      {
        id:1, title:'Load DB', action:'Load-DB', 
        desc:`When click this button, the server running on Host
          and make a recursive research for find apps and setup on db
          and finnaly we will have on the site.`, 
        url:`/accounts/admin/${idAdmin}/load_db/audios`,
        className:'load_db',
      },
      {
        id:2, title:'Reset DB', action:'Reset-DB', 
        desc:`When click this button, the server connected by database
          remove all docs from database, leave the site without any files`, 
        url:`/accounts/admin/${idAdmin}/reset_db/audios`,
        className:'reset_db',
      },
    ];
}


export default function AudiosManager(){
  const [adminPassword, setAdminPassword] = useState('');
  const handlerOnClickAction = (e) => {
    e.preventDefault();
    let form = document.forms.actionForm;
    //config.log('apps-manager.jxs; handler', e.target, form.adminPassword.value);
    setAdminPassword(form.adminPassword.value);
  }

  let result;
  result = sections.map(sect => 
    <SetupDb 
      key={sect.id}  
      title={sect.title}
      action={sect.action}
      desc={sect.desc}
      url={sect.url}
      className={sect.className}
      adminPassword={adminPassword}
    />
  )

  switch(ReactSession.get('lang')){
    default:
      return(
        <div className='admin-manager-container'>
          <h1>Audios Manager</h1>
            <div className="admin-manager" >
            <Form onClick={handlerOnClickAction} method='POST' name='actionForm'>
              <input type="password" placeholder='Type admin password' 
                name='adminPassword'required/>
              <div className="action-list">
                {result}
              </div>
            </Form>
          </div>
        </div>
      );

    case 'pt':
      return(
        <div className='admin-manager-container'>
          <h1>Gerenciador de Aúdios</h1>
            <div className="admin-manager" >
            <Form onClick={handlerOnClickAction} method='POST' name='actionForm'>
              <input type="password" placeholder='Digite a senha do administrador' 
                name='adminPassword'required/>
              <div className="action-list">
                {result}
              </div>
            </Form>
          </div>
        </div>
      );
  }
}