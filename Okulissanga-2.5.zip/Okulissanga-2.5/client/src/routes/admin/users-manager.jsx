import axios from 'axios';
import React, {Component} from 'react';
import { ReactSession } from 'react-client-session';
import {
} from 'react-router-dom';
import config from '../../lib/config';
import {Row} from '../partials/Custom';
// import UserEdit from '../partials/User-Edit';
import '../../css/admin/users-manager.css';

export default class UsersManager extends Component{
  constructor(props){
    super(props);
    this.state = {user: null, users: null};
  }

  componentDidMount(){
    let id = ReactSession.get('_id') || '';
    let url = `/accounts/admin/${id}/users_manager/ALL`;
    // Create/Using the IEE function
    (async () => {
      try{
        let result = await axios.post(url);
        //config.log('users-manager.jsx; componentDidMount(); response ', result);
        this.setState({users: result.data});
      }catch(e){
        config.error('E: *** /admin/home/:id/users_manager', e.response);
      }
    })()  // Calling the function
  }

  onClickHandler = (e) => {
    e.preventDefault();
    // Extract the last piece of href (url) splited by '/'
    let href = e.target.href.split('/');
    let idUser = href[href.length - 1]
    // Filter the users and catch the target
    let user = this.state.users.filter(user => user._id === idUser)[0];
    //config.log('users-manager onClickHandler()', e.target, e.target.href, idUser, this.state.users, user);
    this.setState({user});
  }

  renderUsers(users){
    // Display the users (some info) on table
    let content = users.map( user =>  
        <Row key={user._id}
          _id={user._id}
          name={user.name} 
          gender={user.gender}
          email={user.email}
          phoneNumber={user.phoneNumber}
          status={user.status}
          />
      );
    switch(ReactSession.get('lang')){
      default:
        return (
          <table>
            <thead>
              <tr>
                <th>ID (Edit User)</th>
                <th>Name</th>
                <th>Gender</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {content}
            </tbody>
          </table>
        );

      case 'pt':
        return (
          <table>
            <thead>
              <tr>
                <th>ID (Editar Usuário)</th>
                <th>Nome</th>
                <th>Género</th>
                <th>Email</th>
                <th>Número de telefone</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {content}
            </tbody>
          </table>
        );
    }
  }

  render(){
    //config.log(this.state.users)
    let usersList = null;
    if(this.state.users){
      usersList = this.renderUsers(this.state.users);
    }
    switch(ReactSession.get('lang')){
      default:
        return(
          <div id="users-manager-main">
            <h1>Users Manager</h1>
            <div id="users-list">
              {usersList}
            </div>
          </div>
        );
      case 'pt':
        return(
          <div id="users-manager-main">
            <h1>Users Manager</h1>
            <div id="users-list">
              {usersList}
            </div>
          </div>
        );
    }    
  }//END render()
}