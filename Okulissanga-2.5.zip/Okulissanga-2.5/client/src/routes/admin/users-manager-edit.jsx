import axios from 'axios';
import { ReactSession } from 'react-client-session';
import {
  Form,
  Link,
  redirect,
  useLoaderData,
} from 'react-router-dom';
import config from "../../lib/config";
import Footer from '../partials/Footer';
import Header from '../partials/Header';
import '../../css/admin/users-manager-edit.css';
import ResearchForm from '../partials/Research-Form';

export async function loader({params}){
  const idAdmin = params.idAdmin;
  const idUser = params.idUser;
  let url = `/accounts/users/${idUser}`;
  //config.log('users-manager-edit.jsx; loader()', idUser);
  
  try{
    //Check the idAdmin
    await axios.post(`/accounts/users/${idAdmin}/check_id`);
    //Check the idUser and received the datas exist
    let response = await axios.post(url);
    //config.log(`editing...${idUser}`, response);
    if(response.status === 200){
      return response.data;
    }else{
      return redirect(`/admin/home/${idAdmin}/users_manager?status=404`);
    }
  }catch(e){
    return redirect(`/admin/home/${idAdmin}/users_manager?status=404`);
  }
}

export async function action(){
}

/* *************************** ***************************
              UsersManagerEdit - Page
*************************** *************************** */
export default function UsersManagerEdit(){
  const idAdmin = ReactSession.get('_id');
  let result = useLoaderData();
  let user;
  if(result){
    user = result;
  }

  //Inner-function
  const onSubmitHandler = async (e) => {
    e.preventDefault();
    const form = document.forms.usersManagerEditForm;
    //Verify the password entering by client
    if(!config.verifyPassword(form.password.value, form.password_v.value)){
      let msg =  ReactSession.get('lang') === 'pt' 
                ? 'Palavra-passe não combinam' :
                  'Password not match!';
      alert(msg);
      return null;
    }else{
      delete form.password_v;
    }

    const formData = new FormData();
    formData.append('_id', form._id.value);
    formData.append('email', form.email.value);
    formData.append('phoneNumber', form.phoneNumber.value);
    formData.append('password', form.password.value);
    formData.append('status', form.status.value);
    formData.append('adminPassword', form.adminPassword.value);
   
    config.log('users-manager-edit.jsx; onSubmitHandler() SEND', Object.fromEntries(formData));
   
    //Send datas-users on formData for server
    let msg;
    try{
        await axios.post(
        `/accounts/admin/${idAdmin}/users_manager/EDIT`,
        formData
        );
      if(ReactSession.get('lang') === 'pt'){
        msg = 'Alteração dos dados com sucesso!';
      }else{
        msg = 'Datas changed with Successfully!'; 
      }
      alert(msg);
      document.querySelector('#feedback-users-manager-edit').innerHTML = msg;
    }catch(e){
      if(ReactSession.get('lang') === 'pt'){
        msg = `Erro durante a tentativa de alteração dos dados, 
              favor em verificar a senha do administrador!`;
      }else{
        msg = 'Error when try change the datas, please check admin-password';
      }
      alert(msg);
      config.error('users-manager-edit.jsx; onSubmitHandler()', e.response);
    }
  }//END onSubmitHandler()

  //Take care DELETING - USER
  const onClickHandlerDelete = async (e) => {
    const form = document.forms.usersManagerEditForm;
    //Make safe required on input-field with onClick event
    if(!form.adminPassword.value){
      alert('Please fill the field admin-password');
      return null;
    }

    //Reforce with confirm this action, because isn't UNDO
    let question = ReactSession.get('lang') === 'pt'
                  ? 'Deseja realmente apagar esta conta de usuário?'
                  : 'Do you really delete this account user?';
    if(!prompt(question)){
      return null;
    }

    //Create the form and join the datas for send server
    const formData = new FormData();
    formData.append('_id', form._id.value);
    formData.append('adminPassword', form.adminPassword.value);

    //Make request to server for delete the user-by-id
    try{
      //config.log('users-manager-edit.jsx; onClickHandlerDelete() SEND', Object.fromEntries(formData));
      await axios.post(
            `/accounts/admin/${idAdmin}/users_manager/DELETE`,
            formData
          );
      //config.log('users-manager-edit.jsx; onClickHandlerDelete() RESPONSE',response)
      alert('User Deleted!');
    }catch(e){
      let msg;
      if(ReactSession.get('lang') === 'pt'){
        msg = 'Usuário não eliminado, favor em verificar a senha do administrador!'
      }else{
        msg = 'USER NOT DELETE!, please check admin-password';
      }
      document.querySelector('#feedback-users-manager-edit').innerHTML = msg;
      //config.error('users-manager-edit.jsx; onClickHandlerDelete()',e);
    }
  }//END onClickHandlerDelete

  //Take care render-content
  const renderContent = () => {
    switch(ReactSession.get('lang')){
      default:
        return(
          <div id="users-manager-edit-main">
            <h1>Modify datas for recover users datas</h1>
            <div id='feedback-users-manager-edit' className="feedback-sucess"></div>
            <Form onSubmit={onSubmitHandler} method='POST' name='usersManagerEditForm'>
              <span>ID</span>
              <input type="text" name='_id' defaultValue={user && user._id} disabled/>
              <span>Name</span>
              <input type="text" name='name' defaultValue={user && user.name} disabled/>
              <span>Email</span>
              <input type="email" name='email' defaultValue={user && user.email} required />
              <span>Phone number</span>
              <input type="tel" name='phoneNumber' defaultValue={user && user.phoneNumber} required />
              <span>New Password</span>
              <input type="password" name='password'/>
              <span>Confirm New Password</span>
              <input type="password" name='password_v'/>
              <span>Status</span>
              <input type="text" name='status' defaultValue={user && user.status} />
              <span>Confirm Password Admin for change datas</span>
              <input type="password" name='adminPassword' placeholder='admin-password' required/>
              <div className='go_to_sign'>
                <button type='submit'>Save</button>
                <Link to={`/admin/home/${idAdmin}/users_manager`}>Back</Link>
                <button type='submit' className='reset_db'
                  onClick={onClickHandlerDelete}>
                  Delete User
                </button>
              </div>
            </Form>
          </div>
        );
      
      case 'pt':
        return(
          <div id="users-manager-edit-main">
            <h1>Modifica os dados para a recuperação de dados do usuário</h1>
            <div id='feedback-users-manager-edit' className="feedback-sucess"></div>
            <Form onSubmit={onSubmitHandler} method='POST' name='usersManagerEditForm'>
              <span>ID</span>
              <input type="text" name='_id' defaultValue={user && user._id} disabled/>
              <span>Nome</span>
              <input type="text" name='name' defaultValue={user && user.name} disabled/>
              <span>Email</span>
              <input type="email" name='email' defaultValue={user && user.email} required />
              <span>Número de telefone</span>
              <input type="tel" name='phoneNumber' defaultValue={user && user.phoneNumber} required />
              <span>Nova Senha</span>
              <input type="password" name='password'/>
              <span>Confirmar Nova Senha</span>
              <input type="password" name='password_v'/>
              <span>Status</span>
              <input type="text" name='status' defaultValue={user && user.status} />
              <span>Confirma a senha do Administrador para a modificação dos dados</span>
              <input type="password" name='adminPassword' placeholder='admin-password' required/>
              <div className='go_to_sign'>
                <button type='submit'>Salvar</button>
                <Link to={`/admin/home/${idAdmin}/users_manager`}>Voltar</Link>
                <button type='submit' className='reset_db'
                  onClick={onClickHandlerDelete}>
                    Eliminar usuário
                </button>
              </div>
            </Form>
          </div>
        );
    }
  }//END renderContent()

  //Render all content of page
  return(
    <div id="users-manager-edit-container">
      <Header>
        <ResearchForm />
      </Header>
      {renderContent()}
      <Footer />
    </div>
  );  
}