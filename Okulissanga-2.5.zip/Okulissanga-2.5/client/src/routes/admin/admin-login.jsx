import axios from 'axios';
import { ReactSession } from 'react-client-session';
import {
  Form,
  redirect
} from 'react-router-dom';
import Header from '../partials/Header';
import Footer from '../partials/Footer';
import config from '../../lib/config';
import '../../css/admin/admin-login.css';

//Take care session client
ReactSession.setStoreType('cookie');
ReactSession.set('visited', true);

export async function loader(){
  // Take care session client
  const idAdmin = ReactSession.get('_id');
  try{
    const response = await axios.post(`/accounts/admin/${idAdmin}/check`);
    if(response.status===200){
      return redirect(`/admin/home/${idAdmin}`);
    }
  }catch(e){
    config.error('admin-login.jsx; loader()', e.response);
    return null;
  }
  
}

/* *************************
    Admin-Index - Page
************************* */
export async function action({request}){
  const formData = await request.formData();
  const userData = Object.fromEntries(formData);
  
  let response;
  const url = '/accounts/admin/login'
  config.log('SENDING', userData);
  try{
    response = await axios.post(url, userData);
    if(response.status === 200){
      ReactSession.set('_id', response.data._id);
      ReactSession.set('status', response.data.status);
      return redirect(`/admin/home/${response.data._id}`)
    }else{
      return null;
    }
  }catch(e){
    config.log('error', e.response);
    let msg;
    if(ReactSession.get('lang')==='pt'){
      msg='Credencias enviados Inválidos!';
    }else{
      msg='Invalid credentials!';
    }
    document.querySelector('#feedback-sigin').innerHTML = msg;
    return null;
  }
}

/* render the form for make LOGIN */
export default function AdminLogin(){
  switch(ReactSession.get('lang')){
    default:
      return(
        <div id='admin-login-container'>
          <Header />
          <div id="admin-login-main">
            <div className="form-signin">
                <Form method='POST'>
                  <fieldset>
                    <legend>Administrator Login</legend>
                    <div id="feedback-sigin" className='feedback-invalid'></div>
                    <input type='text' name='email' required 
                      placeholder='Email or phone number'/>
                    <br/>
                    <input type='password' placeholder='Password' name='password' required />
                    <button>Login</button>
                  </fieldset>
                </Form>
            </div>
          </div>
          <Footer />
        </div>
      );

    case 'pt':
      return(
        <div id='admin-login-container'>
          <Header />
          <div id="admin-login-main">
            <div className="form-signin">
                <Form method='POST'>
                  <fieldset>
                    <span id="feedback-sigin" className='feedback-invalid'></span>
                    <legend>Iniciar Sessão (Administrador)</legend>
                    <input type='text' name='email' required 
                      placeholder='Email or número de telefone'/>
                    <br/>
                    <input type='password' placeholder='Senha' name='password' required /> <br/>
                    <button>Entrar</button>
                  </fieldset>
                </Form>
            </div>
          </div>
          <Footer />
        </div>
      );
  }
}