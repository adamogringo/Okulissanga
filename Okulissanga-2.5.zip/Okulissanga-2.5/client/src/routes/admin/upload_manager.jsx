import { ReactSession } from 'react-client-session';
import Upload from '../partials/Upload';

export default function UploadManager(){
  let idUser = ReactSession.get('_id');
  return (
    <div className="UploadManager"> 
      <Upload url={`/accounts/admin/${idUser}/upload`} />
      {/* <Upload url1={`/accounts/users/${idUser}/upload`}/> */}
    </div>
  );
}