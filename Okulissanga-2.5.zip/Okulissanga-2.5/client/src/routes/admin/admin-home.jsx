import axios from 'axios';
import React from 'react';
import { ReactSession } from 'react-client-session';
import {
  Link,
  Outlet,
  redirect,
} from 'react-router-dom';
import Footer from '../partials/Footer';
import Header from '../partials/Header';
import ResearchForm from '../partials/Research-Form';
import '../../css/admin/admin-home.css';

export async function loader({params}){
  let idAdmin = params.idAdmin;
  let url = `/accounts/admin/${idAdmin}`;
  //let result = await get(`/accounts/admin/${idAdmin}`);
  try{
    let result = await axios.post(url);
    if( result.status === 200 &&
      ReactSession.get('_id') === idAdmin){
      return result;
    }else{
      return redirect('/404');
    }
  }catch(e){
    console.error('E: *** /admin/home/:id', e);
    return redirect('/404');
  }
}

//Take care cookie session
ReactSession.setStoreType('cookie');

export default function AdminHome(){
  // Recover the idUser on cookie
  const idAdmin = ReactSession.get('_id');

  switch(ReactSession.get('lang')){
    default:
      return(
        <div id='admin-home-container'>
          <Header>
            <div className='header-node-children'>
              <ResearchForm />
            </div>
          </Header>
          <div id='admin-home-main'>
            <div id='menu'>
              <nav>
                <Link to={`/admin/home/${idAdmin}`}>Status / Statics</Link>
                <Link to={`/admin/home/${idAdmin}/apps_manager`}>Apps Manager</Link>
                <Link to={`/admin/home/${idAdmin}/docs_manager`}>E-Books Manager</Link>
                <Link to={`/admin/home/${idAdmin}/music_manager`}>Audios Manager</Link>
                <Link to={`/admin/home/${idAdmin}/pictures_manager`}>Pictures Manager</Link>
                <Link to={`/admin/home/${idAdmin}/videos_manager`}>Videos Manager</Link>
                <Link to={`/admin/home/${idAdmin}/others_manager`}>Others Manager</Link>
                <Link to={`/admin/home/${idAdmin}/users_manager`}>Users Manager</Link>
                <Link to={`/admin/home/${idAdmin}/upload_manager`}>Upload Manager</Link>
                <Link to={`/users/${idAdmin}`}>Perfil</Link>
                <Link to='/logout'>Logout</Link>
              </nav>
            </div>
            <div className='nested-routes'>
              <Outlet/>
            </div>
          </div>
          <Footer />
        </div>
      );

    case 'pt':
      return(
        <div id='admin-home-container'>
          <Header>
            <div className='header-node-children'>
              <ResearchForm />
            </div>
          </Header>
          <div id='admin-home-main'>
            <div id='menu'>
              <nav>
                <Link to={`/admin/home/${idAdmin}`}>Status / Estatísticas</Link>
                <Link to={`/admin/home/${idAdmin}/apps_manager`}>Gerenciador de Aplicativos</Link>
                <Link to={`/admin/home/${idAdmin}/docs_manager`}>Gerenciador de E-books</Link>
                <Link to={`/admin/home/${idAdmin}/music_manager`}>Gerenciador de Aúdios</Link>
                <Link to={`/admin/home/${idAdmin}/pictures_manager`}>Gerenciador de Imagens</Link>
                <Link to={`/admin/home/${idAdmin}/videos_manager`}>Gerenciador de Vídeos</Link>
                <Link to={`/admin/home/${idAdmin}/others_manager`}>Gerenciador de arquivos compactados</Link>
                <Link to={`/admin/home/${idAdmin}/users_manager`}>Gerenciador de Usuários</Link>
                <Link to={`/admin/home/${idAdmin}/upload_manager`}>Gerenciador de carregamentos</Link>
                <Link to={`/users/${idAdmin}`}>Perfil</Link>
                <Link to='/logout'>Terminar Sessão</Link>
              </nav>
            </div>
            <div className='nested-routes'>
              <Outlet/>
            </div>
          </div>
          <Footer />
        </div>
      );

  }
}