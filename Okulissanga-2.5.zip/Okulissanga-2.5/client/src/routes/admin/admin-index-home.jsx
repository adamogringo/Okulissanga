// Only redirect this route for root-route '/'
import { redirect } from 'react-router-dom';

export async function loader(){
  return redirect('/admin');
}

export default function AdminIndexHome(){
  return null;
}