import axios from 'axios';
import { ReactSession } from 'react-client-session';
import {
  useLoaderData,
} from 'react-router-dom';
import config from '../../lib/config';
import '../../css/admin/admin-status.css';

export async function loader({params}){
  let idAdmin = params.idAdmin;
  let url =  `/accounts/admin/${idAdmin}/info`;
  try{
    let result = await axios(url) //getUser(url);
    //config.log('RESPONSE.DATA', result.data);
    return result.data;
  }catch(e){
    config.error('admin-status.jsx; loader()', e);
  }
}

export default function AdminInfo(){
  let result = useLoaderData();
  switch(ReactSession.get('lang')){
    default:
      return (
        <div id="admin-info">
          <h1>Admin Status - Statics</h1>
          <div id="admin-info-main">
          <div className='statics'>
              <h3>Users</h3>
              <div>
                <div>
                  <h4>Administrador</h4>
                  <p>{result.users.status['admin']}</p>
                </div>
                <div>
                  <h4> users</h4>
                  <p>{result.users.status['user'] - 1}</p>
                </div>
              </div>
            </div>
            <div className='statics'>
              <h3>Apps</h3>
              <div>
                <div>
                  <h4>.apk</h4>
                  <p>{result.apps.fextnames['.apk']}</p>
                </div>
                <div>
                  <h4>.exe</h4>
                  <p>{result.apps.fextnames['.exe']}</p>
                </div>
              </div>
            </div>
            <div className='statics'>
              <h3>E-books</h3>
              <div>
                <div>
                  <h4>.pdf</h4>
                  <p>{result.docs.fextnames['.pdf']}</p>
                </div>
                <div>
                  <h4>.docx</h4>
                  <p>{result.docs.fextnames['.docx']}</p>
                </div>
                <div>
                  <h4>.epub</h4>
                  <p>{result.docs.fextnames['.epub']}</p>
                </div>
              </div>
            </div>
            <div className='statics'>
              <h3>Audios</h3>
              <div>
                <div>
                  <h4>.mp3</h4>
                  <p>{result.audios.fextnames['.mp3']}</p>
                </div>
                <div>
                  <h4>.m4a</h4>
                  <p>{result.audios.fextnames['.m4a']}</p>
                </div>
                <div>
                  <h4>.wma</h4>
                  <p>{result.audios.fextnames['.wma']}</p>
                </div>
                <div>
                  <h4>.ogg</h4>
                  <p>{result.audios.fextnames['.ogg']}</p>
                </div>
              </div>
            </div>
            <div className='statics'>
              <h3>Pictures</h3>
              <div>
                <div>
                  <h4>.jpg</h4>
                  <p>{result.pictures.fextnames['.jpg']}</p>
                </div>
                <div>
                  <h4>.png</h4>
                  <p>{result.pictures.fextnames['.png']}</p>
                </div>
                <div>
                  <h4>.gif</h4>
                  <p>{result.pictures.fextnames['.gif']}</p>
                </div>
              </div>
            </div>
            <div className='statics'>
              <h3>Videos</h3>
              <div>
                <div>
                  <h4>.3gp</h4>
                  <p>{result.videos.fextnames['.3gp']}</p>
                </div>
                <div>
                  <h4>.mkv</h4>
                  <p>{result.videos.fextnames['.mkv']}</p>
                </div>
                <div>
                  <h4>.mp4</h4>
                  <p>{result.videos.fextnames['.mp4']}</p>
                </div>
                <div>
                  <h4>.avi</h4>
                  <p>{result.videos.fextnames['.avi']}</p>
                </div>
                <div>
                  <h4>.mpg</h4>
                  <p>{result.videos.fextnames['.mpg']}</p>
                </div>
                <div>
                  <h4>.mov</h4>
                  <p>{result.videos.fextnames['.mov']}</p>
                </div>
              </div>
            </div>
            <div className='statics'>
              <h3>Others</h3>
              <div>
                <div>
                  <h4>.gz</h4>
                  <p>{result.others.fextnames['.gz']}</p>
                </div>
                <div>
                  <h4>.zip</h4>
                  <p>{result.others.fextnames['.zip']}</p>
                </div>
                <div>
                  <h4>.iso</h4>
                  <p>{result.others.fextnames['.iso']}</p>
                </div>
                <div>
                  <h4>.rar</h4>
                  <p>{result.others.fextnames['.rar']}</p>
                </div>
              </div>
            </div>
          </div>
      </div>
      );
                                                                                  
    case 'pt':    // The same thing, but in other language
      return (
        <div id="admin-info">
          <h1>Administrador Status/Statísticas</h1>
          <div id="admin-info-main">
          <div className='statics'>
              <h3>Usuários</h3>
              <div>
                <div>
                  <h4>administrador</h4>
                  <p>{result.users.status['admin']}</p>
                </div>
                <div>
                  <h4>Usuários</h4>
                  <p>{result.users.status['user'] - 1}</p>
                </div>
              </div>
            </div>
            <div className='statics'>
              <h3>Aplicativos</h3>
              <div>
                <div>
                  <h4>.apk</h4>
                  <p>{result.apps.fextnames['.apk']}</p>
                </div>
                <div>
                  <h4>.exe</h4>
                  <p>{result.apps.fextnames['.exe']}</p>
                </div>
              </div>
            </div>
            <div className='statics'>
              <h3>E-Books</h3>
              <div>
                <div>
                  <h4>.pdf</h4>
                  <p>{result.docs.fextnames['.pdf']}</p>
                </div>
                <div>
                  <h4>.docx</h4>
                  <p>{result.docs.fextnames['.docx']}</p>
                </div>
                <div>
                  <h4>.epub</h4>
                  <p>{result.docs.fextnames['.epub']}</p>
                </div>
              </div>
            </div>
            <div className='statics'>
              <h3>Aúdios</h3>
              <div>
                <div>
                  <h4>.mp3</h4>
                  <p>{result.audios.fextnames['.mp3']}</p>
                </div>
                <div>
                  <h4>.m4a</h4>
                  <p>{result.audios.fextnames['.m4a']}</p>
                </div>
                <div>
                  <h4>.wma</h4>
                  <p>{result.audios.fextnames['.wma']}</p>
                </div>
                <div>
                  <h4>.ogg</h4>
                  <p>{result.audios.fextnames['.ogg']}</p>
                </div>
              </div>
            </div>
            <div className='statics'>
              <h3>Imagens</h3>
              <div>
                <div>
                  <h4>.jpg</h4>
                  <p>{result.pictures.fextnames['.jpg']}</p>
                </div>
                <div>
                  <h4>.png</h4>
                  <p>{result.pictures.fextnames['.png']}</p>
                </div>
                <div>
                  <h4>.gif</h4>
                  <p>{result.pictures.fextnames['.gif']}</p>
                </div>
              </div>
            </div>
            <div className='statics'>
              <h3>Vídeos</h3>
              <div>
                <div>
                  <h4>.3gp</h4>
                  <p>{result.videos.fextnames['.3gp']}</p>
                </div>
                <div>
                  <h4>.mkv</h4>
                  <p>{result.videos.fextnames['.mkv']}</p>
                </div>
                <div>
                  <h4>.mp4</h4>
                  <p>{result.videos.fextnames['.mp4']}</p>
                </div>
                <div>
                  <h4>.avi</h4>
                  <p>{result.videos.fextnames['.avi']}</p>
                </div>
                <div>
                  <h4>.mpg</h4>
                  <p>{result.videos.fextnames['.mpg']}</p>
                </div>
                <div>
                  <h4>.mov</h4>
                  <p>{result.videos.fextnames['.mov']}</p>
                </div>
              </div>
            </div>
            <div className='statics'>
              <h3>Outros Ficheiros</h3>
              <div>
                <div>
                  <h4>.gz</h4>
                  <p>{result.others.fextnames['.gz']}</p>
                </div>
                <div>
                  <h4>.zip</h4>
                  <p>{result.others.fextnames['.zip']}</p>
                </div>
                <div>
                  <h4>.iso</h4>
                  <p>{result.others.fextnames['.iso']}</p>
                </div>
                <div>
                  <h4>.rar</h4>
                  <p>{result.others.fextnames['.rar']}</p>
                </div>
              </div>
            </div>
          </div>
      </div>
      );
  }
}