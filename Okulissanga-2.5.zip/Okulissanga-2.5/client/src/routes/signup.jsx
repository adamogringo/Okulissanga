import {ReactSession} from 'react-client-session';
import React, {Component} from 'react';
import { 
    Form, 
		redirect,
		Link,
} from 'react-router-dom';
import config from '../lib/config';
import Footer from './partials/Footer';
import Header from './partials/Header';
import '../css/signup.css';

export async function action({request}){
    const formData = await request.formData();
    const userDatas = Object.fromEntries(formData);
    //Verify the password entering by client
    if(!config.verifyPassword(userDatas.password, userDatas.password_v)){
      let msg =  ReactSession.get('lang') === 'pt' 
                ? 'Palavra-passe não combinam' :
                  'Password not match!';
      document.querySelector('#feedback-signup').innerHTML = msg;
      return null;
    }else{
      delete userDatas.password_v;
    }
    //Verify the birthday (the date) entering by client
    if(!config.verifyBirthDay(userDatas.birthday)){
      let msg =  ReactSession.get('lang') === 'pt' 
                ? 'Verifica sua idade deves ter no mínimo >= 15 anos!' :
                  'Check your age, must have >= 15 anos';
      document.querySelector('#feedback-signup').innerHTML = msg;
      config.log('INVALID Birthday!', userDatas.birthday, (new Date(userDatas.birthday).getYear()));
      return null;
    }
    //config.log('Making the new register and sending\n', userDatas);
    // Sending this datas on database, using 'fetch'
    return(
			fetch(`/accounts/signup`, {
                method:'POST', 
                headers:{'Content-Type':'application/json'},
                body:JSON.stringify(userDatas)
            }
        )
        .then(response => response.json())
        .then(response => {
            console.log('Response: ', response);
						if(response.ok){
							//document.querySelector('#feeback-signup').innerHTML = 'Cadastre with Successfull!';
							alert('Cadastre with Successfull!');
							return redirect('/signin');
						}else{
							document.querySelector('#feedback-signup').innerHTML = 'Failed Cadastre! ' + response.message;
                return redirect('/signup?email=existent');
						}
        })
        .catch(error => {
            config.error('E:*** /signup (NOT MAKE REQUEST)', error);
        })
			
		);
}

/* ****************************
  Signup - Page
**************************** */
export default class SignUp extends Component{
  renderContent(){
    switch(ReactSession.get('lang')){
      default:
        return(
          <div id='signup-container'>
					  <Header />
              <div id="signup-form">
                <Form method='post'>
                    <fieldset>
                      <legend>Create New Account</legend>
                      <div id="feedback-signup" className='feedback-invalid'></div>
                      <input type="text" placeholder='Full Name' name='name' required />
                      <input type="email" placeholder='Email (example@correio)' name='email' required />
                      <input type="tel" name='phoneNumber' required 
                        placeholder='Phone Number (example +244 900 123 456)'/>
                      <input type="password" placeholder='Password' name='password' required/> 
                      <input type="password" placeholder='Confirm password' name='password_v' required/> 
                      <span>Select Gender</span>
                      <select name='gender'>
                        <option value="Female">Female</option>
                        <option value="Male">Male</option>
                        <option value="Other">Other</option>
                      </select>
                      <input type="text" name='location'
                        placeholder='Location(country, province, street)'/>
                      <input type="text" name='jobs' placeholder='Jobs, Work'/>
                      <span>Birthday</span><br/>
                      <input type="date"  name='birthday' required/>
                      <div className='go_to_sign'>
                        <button type='submit'>Register</button>
                        <Link to='/signin'>Login</Link>
                      </div>
                    </fieldset>
                </Form>
            </div>
						<Footer />
					</div>
        );
        
      case 'pt':
        return(
          <div id='signup-container'>
          <Header />
            <div id="signup-form">
                <Form method='post'>
                    <fieldset>
                      <legend>Criar Nova Conta</legend>
                      <input type="text" placeholder='Nome Completo' name='name' required />
                      <input type="email" placeholder='Email' name='email' required /> 
                      <input type="tel" name='phoneNumber' required 
                        placeholder='Número de telefone (example +244 900 123 456)'/>
                      <input type="password" placeholder='Senha' name='password' required/> 
                      <input type="password" placeholder='Confirma senha' name='password_v' required/>
                      <span>Seleciona o género</span>
                      <select name='gender'>
                        <option value="Feminino">Feminino</option>
                        <option value="Masculino">Masculino</option>
                        <option value="Outro">Outro</option>
                      </select>
                      <input type="text" placeholder='Localização (país, província, cidade)' name='location'/> <br/>
                      <input type="text" name='jobs' placeholder='Ocupação, Trabalho'/>
                      <span>Data de nascimento</span>
                      <input type="date"  name='birthday'/> 
                      <div id="feedback-signup" className='feedback-invalid'></div>
                      <div className='go_to_sign'>
                        <button type='submit'>Registrar</button>
                        <Link to='/signin'>Entrar</Link>
                      </div>
                    </fieldset>
                </Form>
              </div>
            <Footer />
          </div>
        );
    }
  }

  render(){
      return this.renderContent();
  }
}