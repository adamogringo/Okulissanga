import { ReactSession } from 'react-client-session';
import React, {Component} from 'react';
import {
    Link,
    redirect
} from 'react-router-dom';

import Footer from './partials/Footer';
import Header from './partials/Header';
import config from '../lib/config'
import '../css/index.css';
import SelectLanguage from './partials/SelectLanguage';


// Take care session client by 1st time
ReactSession.setStoreType('cookie');
ReactSession.set('visited', true);

export async function loader(){
  // Take care of language when web site is accessed by DEFAULT
  if(!ReactSession.get('lang')){
    if(config.getLang().split('-').filter(item => item === 'pt').length){
      ReactSession.set('lang', 'pt');   // 'pt' -> 'portuguese'
    }else{
      ReactSession.set('lang', 'en'); // 'en' -> 'english'
    }
  }
  //Verify by client-session
  const idUser = ReactSession.get('_id') ? ReactSession.get('_id') : '';
  //config.log('index.jsx; loader(); idUser', idUser);
  if(idUser){
    return redirect(`/home/${idUser}`);
  }
  return null; 
}

/* *************************************
  Main-Class as Component & Route
 ************************************* */ 
export default class Index extends Component{
  constructor(props){
    super(props);
    this.state = {lang: null}
  }

  onClickHandler = (e) => {
    //Just change the value for force render again!
    this.setState({lang: ReactSession.get('lang')});
  }

  renderContent(){
    //Render the content from lang native on browser
    // or from selection by client
    switch(ReactSession.get('lang')){
      default:
        return(
          <div id='index-page-container'>
            <Header className='partials'>
              <section id='select-language' onClick={this.onClickHandler}>
                <SelectLanguage/>
              </section>
            </Header>
            <div id="index" className='partials'>
              <h1>Welcome on Okulissanga</h1>
              <section>
                <h2><Link to="/signin">Sign in</Link></h2>
                <p>Login and explorer this universe</p>
                </section>
              <section>
                <h2><Link to="/signup">Sign up</Link></h2>
                <p>or case is new in here, please make your cadastre</p>    
              </section>
              <section>
                <h2>What'is ?</h2>
                <p>
                    This project is about research files on system operational <br/>
                    and up on browser system making avalible for any devices on network.
                </p>
              </section>
              <section>
                <h2>Who are we ?</h2>
                <p>
                    We are anyone.<br/>
                    Anyone can contribute in this project (platform)
                </p>
              </section>
              <section>
                <h2>Where are we ?</h2>
                <p>
                    We are anywhere.<br/>
                    When online the web site you can access anywhere
                </p>
              </section>
          </div>
          <Footer className='partials' />
        </div>
      );

      case 'pt':
        return(
          <div id='index-page-container'>
            <Header className='partials'>
              <section id='select-language' 
                onClick={this.onClickHandler}
                onChange={this.onClickHandler}>
                <SelectLanguage />  
              </section>
            </Header>
            <div id="index" className='partials'>
                <h1>Bem vindo(a) ao Okulissanga</h1>
                <section>
                  <h2><Link to="/signin">Entrar</Link></h2>
                  <p>
                    Entra e explora este universo...
                  </p>
                </section>
                <section>
                  <h2><Link to="/signup">Cadastrar-se</Link></h2>
                  <p>
                    or caso seja novo aqui e ainda não tenha feito o seu cadastro.
                  </p>
                </section>
                <section>
                  <h2>O quê é ?</h2>
                  <p>
                    Este projeto é sobre pesquisas de ficheiros em sistemas operacionais <br/>
                    e trazer para o browser (Web) tornando os mesmos arquivos disponíves na rede
                  </p>
                </section>
                <section>
                  <h2>Quem somos ?</h2>
                  <p>
                    Somos qualquer um.<br/>
                    Qualquer um pode contribuir neste projeto.
                  </p>
                </section>
                <section>
                  <h2>Onde estamos ?</h2>
                  <p>
                    Estamos em qualquer lugar.<br/>
                    Quando estiver conectado/online poderá acessar a web site (plataforma),
                    em qualquer lugar
                  </p>
                </section>
            </div>
            <Footer className='partials' />
          </div>
      );   
    }
  }
  render(){
    return this.renderContent();
  }
}