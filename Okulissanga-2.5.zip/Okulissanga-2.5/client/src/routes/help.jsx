import { ReactSession } from 'react-client-session';
import Footer from "./partials/Footer";
import Header from "./partials/Header";
import '../css/help.css';


/* ****************************
  Help- Page
**************************** */
export default function Help(){
  switch(ReactSession.get('lang')){
    default:
      return(
        <div id='help-container'>
          <Header/>
          <div id="help-main">
            <h1>Okulissanga - Help</h1>
            <section>
              <ul>
                <li><a href="#what_is" >What's</a></li>
                <li><a href='#how_works'> How Works ? </a></li>
                <li><a href="#how_contribute">How Contribute ?</a></li>
                <li id='faqs'>
                  <a href="#faqs">FAQs</a>
                  <ul>
                    <li><a href="#what_is_mean_okulissanga">What's mean OKULISSANGA</a></li>
                    <li><a href="#how_recover_account">How Recover my account ?</a></li>
                  </ul>
                </li>
                <li><a href="#contacts">Contacts</a></li>
              </ul>
            </section>
            <section>
            <h2 id='what_is'>What's ?</h2>
              <p>
                This project is about take the files on machine and put on web
              </p>
            </section>
            <section>
              <h2 id='how_works'>How Works ?</h2>
              <p>
                The client just make your sign up if was first time that visit the site<br/> 
                and make login and explorer<br/>the web-site. 
              </p>
            </section>
            <section>
              <h2 id="how_contribute">How Contribute</h2>
              <p>
                Like all project open-source the client can contribuite with <br/>
                different way, with donatives, with innovation, improving the codes <br/>
              </p>
            </section>
            <section>
              <h2 id="faqs">FAQ's</h2>
              <dl>
                <dt id="what_is_mean_okulissanga">What's mean OKULISSANGA</dt>
                <dd>
                  OKULISSANGA, is the word that from Umbundu language<br/>
                  (Umbundu is the national language in Angola country)
                </dd>
                <dt id="how_recover_account">How Recover my account ?</dt>
                <dd>In case of forgetten your login of access you can contact the admin</dd>
              </dl>
            </section>
            <section id="contacts">
              <h2>Contacts</h2>
                <h4>Developer</h4>
                <p>+244 941 045 704</p>
                <p>adamogringo@gmail.com</p>
            </section>
          </div>
          <Footer />
        </div>
      );
    
    case 'pt':
      return(
        <div id='help-container'>
          <Header/>
          <div id="help-main">
            <h1>Okulissanga - Ajuda</h1>
            <section>
              <ul>
                <li><a href="#what_is" >O que é ?</a></li>
                <li><a href='#how_works'>Como funciona ? </a></li>
                <li><a href="#how_contribute">Como contribiur ?</a></li>
                <li id='faqs'>
                  <a href="#faqs">FAQs (Perguntas frequentes)</a>
                  <ul>
                    <li><a href="#what_is_mean_okulissanga">O quê significa OKULISSANGA?</a></li>
                    <li><a href="#how_recover_account">Como recuperar minha conta ?</a></li>
                  </ul>
                </li>
                <li><a href="#contacts">Contatos</a></li>
              </ul>
            </section>
            <section>
            <h2 id='what_is'>O quê é ?</h2>
              <p>
                Este projeto é sobre tomar os ficheiros (arquivos) e trazê-los para a web...
              </p>
            </section>
            <section>
              <h2 id='how_works'>Como funciona ?</h2>
              <p>
                Os clientes apenas precisam se cadastrar caso seja a primeira vez que visitam o site,<br/> 
                fazer o login e explorar o web site.
              </p>
            </section>
            <section>
              <h2 id="how_contribute">Como contribuir ?</h2>
              <p>
                Como todos os projetos código aberto os clientes podem contribuir de diversas maneiras,<br/> 
                com donativos, com melhorias, melhorando os códigos fontes.
              </p>
            </section>
            <section>
              <h2 id="faqs">FAQ's (Perguntas frequentes)</h2>
              <dl>
                <dt id="what_is_mean_okulissanga">O quê siginifica OKULISSANGA</dt>
                <dd>
                  OKULISSANGA é uma palavra de origem na língua Umbundu<br/> 
                  (língua esta falada em Angola)
                </dd>
                <dt id="how_recover_account">Como recuperar a minha conta ?</dt>
                <dd>
                  Em casos de esquecimento das credencias para o login deverá contatar o admin....
                </dd>
              </dl>
            </section>
            <section id="contacts">
              <h2>Contatos</h2>
                <h4>Desenvolvedores / Programadores</h4>
                <p>+244 941 045 704</p>
                <p>adamogringo@gmail.com</p>
            </section>
          </div>
          <Footer />
        </div>
      );
  }

  
}