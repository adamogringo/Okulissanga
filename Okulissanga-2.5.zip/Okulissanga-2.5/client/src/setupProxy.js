const { createProxyMiddleware } = require('http-proxy-middleware');
const config  = require('./lib/config');

module.exports = function(app){
    app.use(
        '/api',
        createProxyMiddleware({
            target: `${config.protocol}${config.host}:${config.portServer}`,
            changeOrigin: true,
        })
    );
    app.use(
        '/files',
        createProxyMiddleware({
            target:`${config.protocol}${config.host}:${config.portServer}`,
            changeOrigin: true
        })
    );
    app.use(
        '/accounts',
        createProxyMiddleware({
            target:`${config.protocol}${config.host}:${config.portServer}`,
            changeOrigin: true
        })
    );
};