import 'react-app-polyfill/ie9';
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';
import 'babel-polyfill'

import React from 'react';
import ReactDOM from 'react-dom/client';
import './App.css';
import reportWebVitals from './reportWebVitals';
import {
  createRoutesFromElements,
  createBrowserRouter,
  Route,
  RouterProvider,
} from 'react-router-dom'

// IMPORT ROUTES GENERAL /
//import App from './App';
import Index,
{
  loader as indexLoader
} from './routes/index';
import ErrorPage from './routes/error-page'
import IndexHome,{
  loader as indexHomeLoader
}from './routes/index-home';
import SignUp, {
  action as signUpAction,
} from './routes/signup';
import SignIn, {
  action as signInAction,
  loader as signInLoader
} from './routes/signin';
import Home, {
  loader as homeLoader
} from './routes/home';
import Nav,{
  loader as navLoader
} from './routes/partials/nav';
import Search, {
  loader as searchLoader
} from './routes/partials/Search';
import Help from './routes/help';
// IMPORT ROUTES USERS
import RootAccounts,{
  loader as rootAccountsLoader
} from './routes/users/root-accounts';
import EditUser,{
  loader as editUserLoader,
  action as editUserAction
} from './routes/users/edit-user';
import Logout,{
  loader as logoutLoader
} from './routes/users/logout';
import UserPerfil, { 
  loader as userPerfilLoader,
} from './routes/users/profile';
import UploadImage ,{
  loader as uploadImageLoader,
} from './routes/partials/upload-image';
// IMPORT ROUTES ADMIN
import AdminLogin,{
  action as adminLoginAction,
  loader as adminLoginLoader
}  from './routes/admin/admin-login';
import AdminIndexHome, {
  loader as adminIndexHomeLoader
} from './routes/admin/admin-index-home'
import AdminHome, {
  loader as adminHomeLoader
} from './routes/admin/admin-home';
import AdminInfo, {
  loader as adminInfoLoader
}from './routes/admin/admin-status';
import AppsManager, {
} from './routes/admin/apps-manager';
import DocsManager, {
} from './routes/admin/ebooks-manager';
import AudiosManager from './routes/admin/audios_manager';
import PicturesManager from './routes/admin/pictures-manager';
import VideosManager from './routes/admin/videos_manager';
import OthersManager from './routes/admin/others-manager';
import UsersManager from './routes/admin/users-manager';
import UsersManagerEdit,
{
  loader as usersManagerEditLoader
} from './routes/admin/users-manager-edit';
import UploadManager from './routes/admin/upload_manager';

// CREATE THE ROUTER FOR RENDER
const router = createBrowserRouter(
  createRoutesFromElements(
    <>
      <Route
        index // -> '/'
        element={<Index />}
        loader={indexLoader}
        errorElement={<ErrorPage />}
        />
      <Route 
        path='/home'
        element={<IndexHome />}
        loader={indexHomeLoader}
      />

      <Route 
        path='/signup'
        element={<SignUp />}
        action={signUpAction}
        />
      
      <Route 
        path='/signin'
        element={<SignIn />}
        action={signInAction}
        loader={signInLoader}
      />
      <Route 
        path='/logout'
        element={<Logout />}
        loader={logoutLoader}
      />
      {/* CREATE NESTED ROUTES /home */}
      <Route 
        path='/home/:idUser'
        element={<Home /> }
        loader={homeLoader}
        >
        <Route
          index
          element={<Nav/>}
          loader={navLoader}
          />
      </Route>
      <Route 
        path='/home/:idUser/search'
        element={<Search />}
        loader={searchLoader}
      />
      {/* CREATE NESTED ROUTES /users */}
      <Route
        path='/users/:idUser'
        element={<RootAccounts />}
        loader={rootAccountsLoader}
        >
        <Route
          index
          element={<UserPerfil />}
          loader={userPerfilLoader}
        />
        <Route 
          path='/users/:idUser/edit'
          element={<EditUser />}
          loader={editUserLoader}
          action={editUserAction}
          /> 
      </Route>
      <Route 
        path='/users/:idUser/edit/upload_image'
        element={<UploadImage />}
        loader={uploadImageLoader}
      />
      {/* CREATE ROUTES ADMIN */}
      <Route 
        path='/admin'
        element={<AdminLogin />}
        action={adminLoginAction}
        loader={adminLoginLoader}
        />
      <Route 
        path='/admin/home'
        element={AdminIndexHome}
        loader={adminIndexHomeLoader}
      />  
      {/* CREATE NESTED ROUTES /admin */}
      <Route
        path='/admin/home/:idAdmin'
        element={<AdminHome />}
        loader={adminHomeLoader}
        >
        <Route 
          index
          element={<AdminInfo />}
          loader={adminInfoLoader}
          />
        <Route 
          path='/admin/home/:idAdmin/apps_manager'
          element={<AppsManager />}
          />
        <Route 
          path='/admin/home/:idAdmin/docs_manager'
          element={<DocsManager />}
          />
        <Route 
          path='/admin/home/:idAdmin/music_manager'
          element={<AudiosManager />}
          />
        <Route 
          path='/admin/home/:idAdmin/pictures_manager'
          element={<PicturesManager />}
          />
        <Route 
          path='/admin/home/:idAdmin/videos_manager'
          element={<VideosManager />}
          />
        <Route 
          path='/admin/home/:idAdmin/others_manager'
          element={<OthersManager />}
          />
        <Route 
          path='/admin/home/:idAdmin/users_manager'
          element={<UsersManager />}
          />
        <Route 
          path='/admin/home/:idAdmin/upload_manager'
          element={<UploadManager />}
          />
      </Route>
      {/* END Nested-Routes 1-level */}
      <Route 
          path='/admin/home/:idAdmin/users_manager/:idUser'
          element={<UsersManagerEdit />}
          loader={usersManagerEditLoader}
          />
      <Route 
        path='/help'
        element={<Help />}
      />
    </>
    
  )
);

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
)

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
