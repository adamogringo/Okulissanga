const fs = require('fs');
const path = require('path');
const { File } = require('../mylib/file');

// function toObjUpperCase(obj){
// 	//Put all values from obj on lowercase sensitive
// 	for(let key in obj){
// 		obj[key] = obj[key].toLowerCase();
// 	}
// 	return obj;
// }

// // Make a recursive research on system target
// function findFiles(dir, research){
// 	fs.readdir(dir, (err, files) => {
// 		if(err) throw err;
// 		files.forEach(item => {
// 				item = path.join(dir, item);
// 				try{
// 					if(fs.statSync(item).isDirectory()){
// 						findFiles(item, research);
// 					}else{
// 						// Check the 'research'-> wait a {}
// 						if(research){
// 						//Find anything by:
// 						research = toObjUpperCase(research);
// 						if(path.basename(item.toLowerCase()).indexOf(research.fname) !== -1){
// 							console.log(item);	
// 						}
// 						//console.log('TRYING:', research, ( path.dirname(item.toLowerCase()) ) );
// 						if(path.dirname(item.toLowerCase()).indexOf(research.subpath) !== -1){
// 							console.log(item);
// 						}
// 						if(path.extname(item.toLowerCase().toLowerCase()) === research.extname){
// 							console.log(item);
// 						}
						
// 					//Nothing 'research' specified
// 					}else{
// 						console.log(item);
// 						return function* (item){
// 							yield item;
// 						};	
// 					}
// 				}
// 			}catch(e){
// 				// Error from 'fs.stat'
// 				console.log('E: ***', e);
// 			}
// 			});
// 	});
// }

// EXAMPLE: category = {music:['.mp3', '.wma'], pictures:[.jpg, '.png'], 
//											docs:['.pdf', '.js'], videos:['.mkv', '.mp4']};

//findFilesByCategory('/home/nbrl/Pictures', {videos});
//findFiles('/home/nbrl/Pictures');


// function* genFindFiles(dirname, research){
// 	let contents = fs.readdirSync(dirname);
// 	for(var i=0; i < contents.length; i++){
// 		let item = path.join(dirname, contents[i]);
// 		try{
// 			if(fs.statSync(item).isDirectory()){
// 				//Make recursive calling, but apply yield because it's generator;
// 				for(let value of genFindFiles(item, research)){
// 					yield value;
// 				}
// 			}else{
// 				if(research){
// 					research = toObjUpperCase(research);
// 					if(path.basename(item.toLowerCase()).indexOf(research.fname) !== -1){
// 						console.log(item);	
// 					}
// 					//console.log('TRYING:', research, ( path.dirname(item.toLowerCase()) ) );
// 					if(path.dirname(item.toLowerCase()).indexOf(research.subpath) !== -1){
// 						console.log(item);
// 					}
// 					if(path.extname(item.toLowerCase().toLowerCase()) === research.extname){
// 						console.log(item);
// 					}
// 				}else{
// 					yield item;
// 				}
// 			}
// 		}catch(e){
// 			console.log('E: ', e);
// 		}
// 	}
// }


// Make a research recursive, from DIR filter the results
// from CATEGORY and execute the CALLBACK for each item
findFilesByCategory = function findFilesByCategory(dir, category, callback){
	category.apps = category.apps || [];
	category.applications = category.applications || [];
	category.docs = category.docs || [];
	category.documents = category.documents || [];
	category.music = category.music || [];
	category.pictures = category.pictures || [];
	category.videos = category.videos || [];
	category.others = category.others || [];

	fs.readdir(dir, (err, contents) => {
		if(err) throw err;
		contents.forEach(item => {
			item = path.join(dir, item);
			try{
				if(fs.statSync(item).isDirectory()){
					findFilesByCategory(item, category, callback);	// Recursive calling
				}else{
          let file;            
					//console.log('*****','ANYTHING','******');
          // Make selection from 'category'
					let extname = path.extname(item);
					if(category.apps.find(ext => ext == extname) ||
						category.applications.find(ext => ext == extname)){
						// Make abstraction of filename -> File -> {}
						// Calling the callback custom immediatelly
						file = new File(item);
						((arg) => {
							callback(arg);
						})(file);
					}else if(category.docs.find(ext => ext == extname) 
                || category.documents.find(ext => ext == extname)){
              file = new File(item);
              ((arg) => {
                callback(arg);
              })(file);
					}else if(category.audios.find(ext => ext == extname)){
						file = new File(item);
						((arg) => {
							callback(arg);
						})(file);
					}else if(category.pictures.find(ext => ext == extname)){
						file = new File(item);
						((arg) => {
							callback(arg);
						})(file);
					}else if(category.videos.find(ext => ext == extname)){
						file = new File(item);
						((arg) => {
							callback(arg);
						})(file);
					}else if(category.others.find(ext => ext == extname)){
						file = new File(item);
						((arg) => {
							callback(arg);
						})(file);
					}else{
            //Find anything than weren't be in the category above!
            file = new File(item);
            ((arg) => {
                callback(arg);
              })(file);
            console.log('*****','ANYTHING','******');
          }
				}
			}catch(e){}
		});
	});
}


findFilesByCategory('../public/files/audios',{'audios':['.mp3', '.wma']}, (file) => {
  console.log(file);
  //return file;
});
console.log('*** FINISH *****');