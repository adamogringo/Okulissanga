//const Fs = require( '@supercharge/fs')
const fs = require('fs');
const path = require('path');

// Build like a Model of a filename, then 
// extracts all handy info from a filename
class File{
    constructor(fname){
        this.fpath = decodeURI(fname);
        this.fname = path.basename(fname);
        this.fdirname = path.dirname(fname);
        this.fextname = path.extname(fname);
        this.fsize = fs.statSync(fname).size;
        this.fatime = fs.statSync(fname).atime;  //The Date object-value
        this.fmtime = fs.statSync(fname).mtime;  //The Date object-value
        this.fctime = fs.statSync(fname).ctime;  //The Date object-value
    }
}

exports.File = File;