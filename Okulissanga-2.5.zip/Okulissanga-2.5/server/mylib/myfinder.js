const fs = require('fs');
const path = require('path');
const { File } = require('./file');

// Make a research recursive, from DIR filter the results
// from CATEGORY and execute the CALLBACK for each item
exports.findFilesByCategory = function findFilesByCategory(dir, category, callback){
	category.apps = category.apps || [];
	category.applications = category.applications || [];
	category.docs = category.docs || [];
	category.documents = category.documents || [];
	category.music = category.music || [];
	category.pictures = category.pictures || [];
	category.videos = category.videos || [];
	category.others = category.others || [];

	fs.readdir(dir, (err, contents) => {
		if(err) throw err;
		contents.forEach(item => {
			item = path.join(dir, item);
			try{
				if(fs.statSync(item).isDirectory()){
					findFilesByCategory(item, category, callback);	// Recursive calling
				}else{
					// Make selection from 'category'
					let file;
					let extname = path.extname(item);
					if(category.apps.find(ext => ext == extname) ||
						category.applications.find(ext => ext == extname)){
						// Make abstraction of filename -> File
						// Calling the callback custom immediatelly
						file = new File(item);
						((arg) => {
							callback(arg);
						})(file);
					}else if(category.docs.find(ext => ext == extname) || 
						category.documents.find(ext => ext == extname)){
						file = new File(item);
						((arg) => {
							callback(arg);
						})(file);
					}else if(category.audios.find(ext => ext == extname)){
						file = new File(item);
						((arg) => {
							callback(arg);
						})(file);
					}else if(category.pictures.find(ext => ext == extname)){
						file = new File(item);
						((arg) => {
							callback(arg);
						})(file);
					}else if(category.videos.find(ext => ext == extname)){
						file = new File(item);
						((arg) => {
							callback(arg);
						})(file);
					}else if(category.others.find(ext => ext == extname)){
						file = new File(item);
						((arg) => {
							callback(arg);
						})(file);
					}
				}
			}catch(e){}
		});
	});
}


