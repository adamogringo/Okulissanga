// const {MongoClient} = require('mongodb');

// const url = 'mongodb://localhost:27017';
// const dbName = 'Okulissanga';
// const client = new MongoClient(url);

// exports.checkUserById = async function (id){
//   await client.connect();
//   console.log('connected successfully to server');
//   const db = client.db(dbName);
//   const collection = db.collection('users');
//   const findResult = await collection.find({}).toArray();
//   //console.log('COLLECTION', collection);
//   console.log('Found: ', findResult);
//   return 'done'
// }

// exports.client = client;