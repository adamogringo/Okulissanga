const mongoose = require('mongoose');
const config = require('../../client/src/lib/config');

// HOW MAKE SEARCH ON ALL APIS ????
const Apps = mongoose.model('Apps');
const Docs = mongoose.model('Docs');
const Audios = mongoose.model('Audios');
const Pictures = mongoose.model('Pictures');
const Videos = mongoose.model('Videos');
const Others = mongoose.model('Others');

// For render from all sections make a find async
// Operation chained 
exports.index = (req, res) => {
    let search = req.params.fname;
    //config.log('on SEARCH', search);
		//search = `"${search}"`;		//This template help on research exact more filtered
    Audios.find(
        {$text:{$search: search}},
        (err, audios)=> {
            if(err){
							res.status(404).send({message:`${search} Not Found`});
            }else{
                Apps.find( 
										{$text:{$search:search}},
                    (err, apps)=> {
                        if(err){
                          res.status(404).send({message:`${search} Not Found`});
                        }else{
                            Docs.find(
															{$text:{$search:search}},
															(err, docs) => {
																if(err){
																	res.status(404).send({message:`${search} Not Found`});
																}else{
																	Pictures.find(
																		{$text:{$search:search}},
																		(err, pictures) => {
																			if(err){
																				res.status(404).send({message:`${search} Not Found`});
																			}else{
																				Videos.find(
																					{$text:{$search:search}},
																					(err, videos) => {
																						if(err){
																							res.status(404).send({message:`${search} Not Found`});
																						}else{
																							Others.find(
																								{$text:{$search:search}},
																								(err, others) => {
																									if(err){
																										res.status(404).send({message:`${search} Not Found`});
																									}else{
																										res.status(200).send([...apps, ...docs, ...audios, 
																													...pictures, ...videos, ...others]);
																									}
																								}
																							)
																						}
																					}
																				)
																			}
																		}
																	)
																}
															}
														)
                        }
                    });
            }
        });
    
        
}

// When the client make a search without nothing!
exports.empty = (req, res) => {
	res.status(200).send();
}