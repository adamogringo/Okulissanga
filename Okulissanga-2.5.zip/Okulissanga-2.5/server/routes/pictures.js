const mongoose = require('mongoose');

const Pictures = mongoose.model('Pictures');

exports.section = (req, res) => {
    Pictures.find(
        {},
        (err, data) => {
            if(err){
                console.log('E: ***', err);
            }else{
                res.json(data);
            }
        }
    )
}