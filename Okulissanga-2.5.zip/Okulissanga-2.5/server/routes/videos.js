const mongoose = require('mongoose');

const Videos = mongoose.model('Videos');

exports.section = (req, res) => {
    Videos.find(
        {},
        (err, data) => {
            if(err){
                console.log('E: ***', err);
            }else{
                res.json(data);
            }
        }
    )
}