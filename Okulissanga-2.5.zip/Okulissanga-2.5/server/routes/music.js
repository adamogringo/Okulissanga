const mongoose = require('mongoose');

const Music = mongoose.model('Music');

// API
exports.section = (req, res) => {
    Music.find(
        {},
        (err, data) => {
            if(err){
                console.log('E: ***', err);
            }else{
                res.json(data);
            }
        }
    )
}