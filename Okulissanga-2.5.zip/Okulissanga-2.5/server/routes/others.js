const mongoose = require('mongoose');

const Others = mongoose.model('Others');

// API
exports.section = (req, res) => {   
    Others.find(
        {},
        (err, data) => {
            if(err){
                console.log('E:***', err);
            }else{
                res.json(data);
            }
        }
    )
}