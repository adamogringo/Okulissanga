const mongoose = require('mongoose');

const Audios = mongoose.model('Audios');

// API
exports.section = (req, res) => {
    Audios.find(
        {},
        (err, data) => {
            if(err){
                console.log('E: ***', err);
            }else{
                res.json(data);
            }
        }
    )
}