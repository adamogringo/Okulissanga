const path = require('path')
  ,fs = require('fs')
  ,mongoose = require('mongoose');
const config = require('../../client/src/lib/config');

const Users = mongoose.model('Users');

//app.get('/tests');
exports.tests = (req, res) => {
  config.log('GET /accounts/tests ******');
  Users.find(
    {status:'user'},
    'status',
    (err, data) => {
      if(err){
        res.status(500).send(err);
      }else{
        let user = data[0];
        if(user){
          res.status(200).send({
            ok:true,
            message:'success connection with model Users!',
            date:(new Date).toString()
          });
        }else{
          res.status(404).send()
        }
      }
    }
  );
}

//Helper-Functions
function checkUserByPassword(password, cb){
  Users.find(
    {password: password},
    (err, data) => {
      if(err){
        cb(err);
      }else{
        data=data[0];
        if(data){
          cb({ok: true});
        }else{
          cb({message:'Not found!'});
        }
      }
    }
  );
}

// by POST method
exports.checkId = (req, res) => {
  let idUser = req.params.idUser;
  // Check the ID on database
  Users.find(
    {_id: idUser},
    '_id',
    (err, data) => {
      if(err){
        res.status(500).send({message: err});
      }else{
        data = data[0];
        if(data){
          res.status(200).send({ok: true, user: data});
        }else{
          res.status(404).send({message:'ID user not found!'});
        }
      }
    }
  );
  
}

//app.post('/accounts/signin')
exports.signIn = (req, res) => {
    const userCredentials = req.body;
    //config.log('DEBUG: app.post(/accounts/signin)', userCredentials);
    //Check credentials using EMAIL
    Users.find(
      {email: userCredentials.email},
      'email phoneNumber password status',
      (err, data) => {
        if(err){
          config.error(err);
          res.status(500).send(err);
        }else{
          let user = data[0]; //Filter just one resultSet
          if(user && user.email === userCredentials.email &&
            user.password === userCredentials.password)
          {
            res.status(200).send({_id: user._id, status: user.status});
          }
          else  
          {
            //Check credentialas using PHONE-NUMBER
            userCredentials.phoneNumber = userCredentials.email;
            Users.find(
              {phoneNumber: userCredentials.phoneNumber},
              'email phoneNumber password status',
              (err, data) => {
                if(err){
                  res.send(500).send();
                }else{
                  user = data[0];
                  //config.log('//Check credentialas using PHONE-NUMBER ****', user);
                  if(user && user.phoneNumber === userCredentials.phoneNumber &&
                    user.password === userCredentials.password){
                      res.status(200).send({_id: user._id, status: user.status});
                    }else{
                      res.status(404).send();
                    }
                }
              }
            ); //END action Model 'Users' inner
          }
        }
      }
    ); //END action Model 'Users' outer
};

//app.post('/accounts/signup') 
exports.signUp = (req, res) => {
    const user = req.body;
    //Using the Model for create the datas 
    //and insert to database 'MongoDB'
    Users.create({
        name: user.name,
        email: user.email,
        phoneNumber: user.phoneNumber,
        password: user.password,
        gender: user.gender,
        jobs: user.jobs,
        location: user.location,
        birthday: user.birthday,
    }, (err, data) => {
        if(err){
            if(err.code === 11000){
              config.error('E:*** DUPLICATE', err);
              res.status(500).json({message:'duplicated email', error:err});
            }else{
              config.error('E:*** db', err);
              res.status(500).json({message:'generic error', error:err});
            }
        }else{
          res.status(200).json({message:'User Add!', ok:true})
        }  
    });
};

// FOR REVIEW!!!
exports.login = (req, res) => {
    let idUser = req.params.idUser;
    Users.find(
        {_id: idUser},
        '_id',
        (err, data)=> {
            if(err){
                console.error('E:***', err);
                res.status(500).json({message: err});
            }else{
                res.status(200).json({ok: true, data:data[0]});
            }
        }
    )
};

//app.get('/accounts/users/:idUser')
exports.user = (req, res) => {
  let idUser = req.params.idUser;
  Users.find(
      {_id: idUser},
      'name email phoneNumber gender jobs location birthday imgProfile status',
      (err, data)=> {
          if(err){
            console.error('E:***', err);
            res.status(500).json({message: err});
          }else{
            data=data[0];
            if(data){
              res.status(200).send(data);
            }else{
              res.status(404).send();
            }
          }
      }
  )
}

//app.post('/accounts/users/:idUser/edit')
exports.userEdit = (req, res) => {
  const user = req.body;
  //config.log('Calling *** app.post(/accounts/users/:idUser/edit)', user);
  //Verify the user authentication by password
  checkUserByPassword(user.password_current, (response) => {
    if(response.ok){
      Users.updateOne(
        {_id: user._id },
        {
          name: user.name,
          email: user.email,
          phoneNumber: user.phoneNumber,
          password: user.password,
          gender: user.gender,
          jobs: user.jobs,
          location: user.location,
          birthday: user.birthday,
        },
        (err, data) => {
          if(err){
            console.error('E:*** users.js -> userEdit()');
            return json.status(500).json({message:'Error on update!'})
          }else{
            return res.status(200).json({ok:true});
          }
        }
      )
    }else{
      res.status(404).send();
    }
  }); //END checkUserByPassword 
}

exports.isImgPath = (idUser) => {
  let dirname = './public/users/images';
  config.log('H: ***', `${dirname}/${idUser}`, '***',fs.existsSync(`${dirname}/${idUser}`), '***', __dirname);
  return fs.existsSync(`${dirname}/${idUser}`);
  
}

//app.post('/accounts/users/:idUser/edit/upload_image')
exports.uploadUserImage = (req, res) => {
  let idUser = req.params.idUser;
  config.log('/accounts/users/:idUser/edit/upload_image', req.files, req.body);
  
  if(req.files === null){
    return res.status(400).json({msg:'No file uploaded'});
  }

  const image = req.files.image;
  //let filename = req.body.description;
  // let uFilename = `${image.md5}-${filename.replaceAll(/\s/g, '-')}`;
  let uFilename = `${image.md5}`;

  //Save the UPLOAD to 'dirname'
  let imgProfilePath = `public/users/images/${idUser}/${uFilename}`;
  let dirname = `${path.resolve('.')}/${imgProfilePath}`;
  
  //Create the idUser folder for storage the imgs case !exists
  if(!this.isImgPath(idUser)){
    config.log('CREATING A NEW FOLDER to ', idUser);
    fs.mkdirSync(`${path.resolve('.')}/public/users/images/${idUser}`);
  }

  image.mv(dirname, (err) => {
    if(err){
      console.error(err);
      return res.status(500).send(err);
    }
    // Save path image to 'database'
    Users.updateOne(
      {_id: idUser},
      {$set: {imgProfile: imgProfilePath}},
      (err, data) => {
        if(err){
          return res.status(500).send({error: err});
        }else{
          //res.send({ok:true ,message:'uploading image', data});
        }
      }
    );
    return res.status(200).send();
  });

}
