const mongoose = require('mongoose');
const path = require('path');
const { findFilesByCategory } = require('../mylib/myfinder');
const { File } = require('../mylib/file');
const config = require('../../client/src/lib/config');
const { user } = require('./users');

const Users = mongoose.model('Users');

const Apps = mongoose.model('Apps');
const Docs = mongoose.model('Docs');
const Audios = mongoose.model('Audios');
const Pictures = mongoose.model('Pictures');
const Videos = mongoose.model('Videos');
const Others = mongoose.model('Others');

//app.post('/accounts/admin/login')
exports.login = (req, res) => {
  let user = req.body;
  //config.log('app.post(/accounts/admin/)', user);
  //Trying the login with EMAIL
  Users.find(
    {email: user.email},
    'email password status',
    (err, data) => {
      if(err){
        config.error('E:*** /accounts/admin', err);
        res.status(500).send();
      }else{
        //config.log(`app.post('/accounts/admin/')`, data)
        data = data[0];
        if(data){
          if(data.email===user.email &&  data.password===user.password && data.status==='admin'){
            res.status(200).send({_id:data._id, status: data.status});
          }else{
            res.status(404).send({message:`Invalid login 'email or 'password' incorrect`});
          }
        }else{
          //Try login with phoneNumber
          user.phoneNumber = user.email;
          Users.find(
            {phoneNumber: user.phoneNumber},
            'phoneNumber password status',
            (err, data) => {
              if(err){
                res.status(500).send(err);
              }else{
                //config.log('TRYING NUMBER', user, data);
                data = data[0];
                if(
                  data 
                  && data.phoneNumber === user.phoneNumber 
                  && data.password === user.password 
                  && data.status === 'admin'){
                    res.status(200).send({_id: data._id, status: data.status});
                  }else{
                    res.status(404).send({message:'Email not found! User not registed!'});
                  }
              }
            }
          );
        }
      }//if-elsee OUTER(sucess)
    }
  );
}

// by POST method, check User By ID
// '/accounts/admin/:idAdmin/check'
exports.check = (req, res) => {
  const { idAdmin } = req.params;
  config.log('/accounts/admin/:idAdmin/check', idAdmin);
  checkUserByIdStatus(idAdmin, (response)=> {
    if(response.ok){
      if(response.data.status==='admin'){
        config.log('H:', response);
        res.status(200).send(response);
      }else{
        res.status(450).send(response)  
      }
    }else{
      res.status(404).send(response)
    }
  });
}

//app.post('/accounts/admin/:idAdmin')
exports.home = (req, res) => {
  // Check the _id & status on db
  let idAdmin = req.params.idAdmin;
    Users.find(
      {_id: idAdmin},
      '_id status',
      (err, data) => {
        if(err){
          res.status(500).send({error: err});
        }else{
          data = data[0];
          if(data && data.status === 'admin'){
            res.status(200).send({ok: true, data:data});
          }else{
            res.status(404).send({message:'ID not found!'})
          }
        }
      }
    );
}

exports.info = (req, res) => {
  // Like return statistics of each category
  // Find all files and take the detail for the send
  let apps      = {fextnames:{}},
      docs      = {fextnames:{}},
      audios    = {fextnames:{}},
      pictures  = {fextnames:{}},
      videos    = {fextnames:{}},
      others    = {fextnames:{}}
      users     = {status:{}};
  Apps.find(
    {},
    'fextname', 
    (err, data) => {
      if(err){
        console.error('E:*** /accounts/admin/:idAdmin/info', err);
        res.status(500).json({message: err});
      }else{
        // Get count of each fextname on collection 'apps'
        let fextnames = {}
        data.forEach(file => {
          if(!fextnames[file.fextname])
            fextnames[file.fextname] = 0;
          fextnames[file.fextname] += 1;
        });
        apps.fextnames = fextnames;
        //NEXT QUERY NESTED USING MODEL 'Docs'
        Docs.find(
          {},
          'fextname',
          (err, data) => {
            if(err){
              console.error('E:/accounts/admin/:idAdmin/info', err);
              res.status(500).json({message: err});
            }else{
              // Get count of each fextname on collections 'docs'
              let fextnames = {}
              data.forEach(file => {
                if(!fextnames[file.fextname])
                  fextnames[file.fextname] = 0;
                fextnames[file.fextname] += 1;
              });
              docs.fextnames = fextnames;
              //NEXT QUERY NESTED USING MODEL 'Audios'
              Audios.find(
                {},
                'fextname',
                (err, data) => {
                  if(err){
                    console.error('E:/accounts/admin/:idAdmin/info', err);
                    res.status(500).json({message: err});
                  }else{
                    // Get count of each fextname on collections 'Audioss'
                    let fextnames = {}
                    data.forEach(file => {
                      if(!fextnames[file.fextname])
                        fextnames[file.fextname] = 0;
                      fextnames[file.fextname] += 1;
                    });
                    audios.fextnames = fextnames;
                    //NEXT QUERY NESTED USING MODEL 'Pictures'
                    Pictures.find(
                      {},
                      'fextname',
                      (err, data) => {
                        if(err){
                          console.error('E:/accounts/admin/:idAdmin/info', err);
                          res.status(500).json({message: err});
                        }else{
                          // Get count of each fextname on collection 'pictures'
                          let fextnames = {}
                          data.forEach(file => {
                            if(!fextnames[file.fextname])
                              fextnames[file.fextname] = 0;
                            fextnames[file.fextname] += 1;
                          });
                          pictures.fextnames = fextnames;
                          //NEXT QUERY NESTED USING MODEL 'Videos'
                          Videos.find(
                            {},
                            'fextname',
                            (err, data) => {
                              if(err){
                                console.error('E:/accounts/admin/:idAdmin/info', err);
                                res.status(500).json({message: err});
                              }else{
                                // Get count of each fextname on collections 'videos'
                                let fextnames = {}
                                data.forEach(file => {
                                  if(!fextnames[file.fextname])
                                    fextnames[file.fextname] = 0;
                                  fextnames[file.fextname] += 1;
                                });
                                videos.fextnames = fextnames;
                                //NEXT QUERY NESTED USING MODEL 'Others'
                                Others.find(
                                  {},
                                  (err, data) => {
                                    if(err){
                                      console.error('E:/accounts/admin/:idAdmin/info', err);
                                      res.status(500).json({message: err});
                                    }else{
                                      // Get count of each fextname on collections 'others'
                                      let fextnames = {}
                                      data.forEach(file => {
                                        if(!fextnames[file.fextname])
                                          fextnames[file.fextname] = 0;
                                        fextnames[file.fextname] += 1;
                                      });
                                      others.fextnames = fextnames;
                                      //NEXT QUERY NESTED USING MODEL Users
                                      Users.find(
                                        {},
                                        'status',
                                        (err, data) => {
                                          if(err){
                                            console.error('E:/accounts/admin/:idAdmin/info', err);
                                            res.status(500).json({message: err});
                                          }else{
                                            // Get count of each fextname on collections 'others'
                                            let status = {}
                                            data.forEach(user => {
                                              if(!status[user.status])
                                                status[user.status] = 0;
                                                status[user.status] += 1;
                                            });
                                            users.status = status;
                                            //Finally return all datas with statics about fextnames
                                            res.status(200).json(
                                            {ok: true, apps, docs, audios,
                                            pictures, videos, others, users}
                                            );
                                          }
                                        }
                                      )
                                      
                                    }
                                  }
                                );//END Others Model
                              }
                            }
                          );//END Videos Model
                        }
                      }
                    ); //END Pictures Model
                  }
                }
              );//END Audios Model
            }
          }
        ); //END Docs Model
      }
    }
  )
  
}

function checkUserByIdStatus(id, cb){
  Users.find(
    {_id:id},
    '_id status',
    (err,data) => {
      if(err){
        cb({error: err});
      }else{
        data = data[0];
        if(data && data.status === 'admin'){
          cb({ok:true, data});
        }else{
          cb({message:'Not found!'});
        }
      }
    }
  );
}//End checkUserByStatus()

function checkUserByPasswordStatus(password, cb){
  Users.find(
    {password: password, status:'admin'},
    (err, data) => {
      if(err){
        cb({error: err});
      }else{
        data = data[0];
        if(data){
          cb({ok: true, data});
        }else{
          cb({message:'Not found!'});
        }
      }
    }
  )
}//END checkUserByPasswordStatus()

function checkUserByIdPasswordStatus(id, password, status, cb){
  Users.find(
    {_id:id, password: password, status: status},
    (err, data) => {
      if(err){
        cb({error: err});
      }else{
        let user = data[0];
        if(user){
          cb({ok: true});
        }else{
          cb({message:'Credentials Not found!'});
        }
      }
    }
  );
}

// app.post('/accounts/admin/:idAdmin/load_db/apps')
exports.loadDBApps = (req, res) => {  
  let {idAdmin} = req.params;
  let status        = 'admin',
      adminPassword = req.body.adminPassword;

  config.log('/accounts/admin/:idAdmin/load_db/apps','LOADING...DB');
  checkUserByIdPasswordStatus(idAdmin, adminPassword, status,  (response) => {
    if(response.ok){
      let dirname = 'public/files/apps',  // Root Research
	    category = {apps:config.fextname.apps};
      // Calling the functions-recursive and set collection
      findFilesByCategory(
        dirname, 
        category, 
        (file) => {
          Apps.create(
            {
              fpath: file.fpath,
              fname: file.fname, 
              fsize: file.fsize,
              fextname: file.fextname,
              fdirname: file.fdirname,
              fatime: file.fatime,
              fmtime: file.fmtime,
              fctime: file.fctime
            },
            (err, data) => {
              if(err){
                if(err.code === 11000){
                  config.log('E: DUPLICATE ***', err.keyValue);
                }else{
                  config.log('E:*** ', err);
                }
              }else{	
                config.log('Added',data.fpath ); // Success
              }
            }
          )
        });
      //Send the Feedback
      res.status(200).json(response)
    }else{
      res.status(404).json(response)
    }
  });
};

// app.post('/accounts/admin/:idAdmin/reset_db/apps')
exports.resetDBApps = (req, res) => {
  let {idAdmin} = req.params;
  let status        = 'admin',
      adminPassword = req.body.adminPassword;
  config.log('/accounts/admin/:idAdmin/reset_db/apps', 'RESETING... DB', req.body);
  // Make safe operation checking the credentials!
  checkUserByIdPasswordStatus(idAdmin, adminPassword, status, (response) => {
    if(response.ok){
      //Clean all datas on collection 'Apps'
      Apps.deleteMany(
        {},
        (err, data) => {
          if(err){
            res.status(500).send(err);
          }else{
            res.status(200).send(data);
          }
        }
      );
    }else{
      res.status(404).send(response);
    }
  })
}

exports.loadDBDocs = (req, res) => {
  let {idAdmin} = req.params;
  let status        = 'admin',
      adminPassword = req.body.adminPassword;
	config.log('/accounts/admin/:idAdmin/load_db/docs', 'LOADING...DB');
  let dirname = './public/files/docs',
      category = {docs: config.fextname.docs};
  // Make safe operation checking the credentials!
  checkUserByIdPasswordStatus(idAdmin, adminPassword, status, (response) => {
    if(response.ok){
      // Calling the functions-recursive and set collection
      findFilesByCategory(
        dirname, 
        category, 
        (file) => {
          Docs.create(
            {
              fpath: file.fpath,
              fname: file.fname, 
              fsize: file.fsize,
              fextname: file.fextname,
              fdirname: file.fdirname,
              fatime: file.fatime,
              fmtime: file.fmtime,
              fctime: file.fctime
            },
            (err, data) => {
              if(err){
                if(err.code === 11000){
                  config.log('E: DUPLICATE ***', err.keyValue);
                }else{
                  config.log('E:*** ', err);
                }
              }else{	// Success
                config.log('Added',data.fpath );
              }
            }
          )
        });
      res.status(200).send(response);
    }else{
      res.status(404).send(response);
    }
  });
		
};

//app.post('/accounts/admin/:idAdmin/reset_db/docs')
exports.resetDBDocs = (req, res) => {
  let {idAdmin} = req.params;
  let status        = 'admin',
      adminPassword = req.body.adminPassword;
  config.log('/accounts/admin/:idAdmin/reset_db/docs', 'RESETING... DB');
  // Make safe operation checking the credentials
  checkUserByIdPasswordStatus(idAdmin, adminPassword, status, (response) => {
    if(response.ok){
      //Clean all datas on collection 'Docs'
      Docs.deleteMany(
        {},
        (err, data) => {
          if(err){
            res.status(500).send(err);
          }else{
            res.status(200).send(data);
          }
        }
      );
    }else{
      res.status(404).send(response);
    }
  });
}

//app.post('/accounts/admin/:idAdmin/load_db/audios')
exports.loadDBAudios = (req, res) => {
  let {idAdmin}     = req.params,
      status        = 'admin',
      adminPassword = req.body.adminPassword;
	config.log('/accounts/admin/:idAdmin/load_db/audios','LOADING...DB');
	let dirname = './public/files/audios',
		category = {audios:config.fextname.audios};
  //Make a safe operation checking the credentials
  checkUserByIdPasswordStatus(idAdmin,adminPassword, status, (response) => {
    if(response.ok){
      // Calling the functions-recursive and set collection
      findFilesByCategory(
        dirname, 
        category, 
        (file) => {
          Audios.create(
            {
              fpath: file.fpath,
              fname: file.fname, 
              fsize: file.fsize,
              fextname: file.fextname,
              fdirname: file.fdirname,
              fatime: file.fatime,
              fmtime: file.fmtime,
              fctime: file.fctime
            },
            (err, data) => {
              if(err){
                if(err.code === 11000){
                  config.log('E: DUPLICATE ***', err.keyValue);
                }else{
                  config.error('*** Must *** REBOOT *** Server',err);
                }
              }else{	// Success
                config.log('Added',data.fpath );
              }
            }
          )
        });
      res.status(200).send(response);
    }else{
      res.status(404).send(response);
    }
  });
};

exports.resetDBAudios = (req, res) => {
  let {idAdmin}     = req.params,
      status        = 'admin',
      adminPassword = req.body.adminPassword;
  config.log('/accounts/admin/:idAdmin/reset_db/audios', 'RESETING... DB');
  //Make a safe operation checking the credentials
  checkUserByIdPasswordStatus(idAdmin, adminPassword, status, (response) => {
    if(response.ok){
      //Clean all datas on collection 'Audios'
      Audios.deleteMany(
        {},
        (err, data) => {
          if(err){
            res.status(500).send(err);
          }else{
            res.status(200).send(data);
          }
        }
      );
    }else{
      res.status(404).send(response);
    }
  });
}

//app.post('/accounts/admin/:idAdmin/load_db/audios')
exports.loadDBPictures = (req, res) => {
  let {idAdmin}     = req.params,
      status        = 'admin',
      adminPassword = req.body.adminPassword;
	config.log('/accounts/admin/:idAdmin/load_db/pictures','LOADING...DB');
	let dirname = './public/files/pictures',
		  category = {pictures: config.fextname.pictures};
  // Make safe operation checking the credentials!
  checkUserByIdPasswordStatus(idAdmin, adminPassword, status, (response) => {
    if(response.ok){
      // Calling the functions-recursive and set collection
      findFilesByCategory(
        dirname, 
        category, 
        (file) => {
          Pictures.create(
            {
              fpath: file.fpath,
              fname: file.fname, 
              fsize: file.fsize,
              fextname: file.fextname,
              fdirname: file.fdirname,
              fatime: file.fatime,
              fmtime: file.fmtime,
              fctime: file.fctime
            },
            (err, data) => {
              if(err){
                if(err.code === 11000){
                  config.log('E: DUPLICATE ***', err.keyValue);
                }else{
                  config.log('E:*** ', err);
                }
              }else{	// Success
                config.log('Added',data.fpath );
              }
            }
          )
        });
      res.status(200).send(response);
    }else{
      res.status(404).send(response);
    }
  });
	
};

exports.resetDBPictures = (req, res) => {
  let {idAdmin}     = req.params,
      status        = 'admin',
      adminPassword = req.body.adminPassword;
  config.log('/accounts/admin/:idAdmin/reset_db/pictures', 'RESETING... DB');
  // Make safe operation checking the credentials!
  checkUserByIdPasswordStatus(idAdmin, adminPassword, status, (response) => {
    if(response.ok){
      //Clean all datas on collection 'Audios'
      Pictures.deleteMany(
        {},
        (err, data) => {
          if(err){
            res.status(500).send(err);
          }else{
            res.status(200).send(data);
          }
        }
      );
    }else{
      res.status(404).send(response);
    }
  });
}

//app.post('/accounts/admin/:idAdmin/load_db/videos')
exports.loadDBVideos = (req, res) => {
  let {idAdmin}     = req.params,
      status        = 'admin',
      adminPassword = req.body.adminPassword;
	config.log('/accounts/admin/:idAdmin/load_db/videos', new Date(),'LOADING...DB');
	let dirname = './public/files/videos',
		  category = {videos: config.fextname.videos};
  // Make safe operation checking the credentials!
  checkUserByIdPasswordStatus(idAdmin, adminPassword, status, (response) => {
    if(response.ok){
      // Calling the functions-recursive and set collection
      findFilesByCategory(
        dirname, 
        category, 
        (file) => {
          Videos.create(
            {
              fpath: file.fpath,
              fname: file.fname, 
              fsize: file.fsize,
              fextname: file.fextname,
              fdirname: file.fdirname,
              fatime: file.fatime,
              fmtime: file.fmtime,
              fctime: file.fctime
            },
            (err, data) => {
              if(err){
                if(err.code === 11000){
                  config.log('E: DUPLICATE ***', err.keyValue);
                }else{
                  config.log('E:*** ', err);
                }
              }else{	// Success
                config.log('Added',data.fpath );
              }
            }
          )
        });
      res.status(200).send(response);
    }else{
      res.status(404).send(response);
    }
  })
	
};

//app.post('/accounts/admin/:idAdmin/reset_db/videos')
exports.resetDBVideos = (req, res) => {
  let {idAdmin}     = req.params,
      status        = 'admin',
      adminPassword = req.body.adminPassword;
  config.log('/accounts/admin/:idAdmin/reset_db/videos', 'RESETING... DB');
  // Make safe operation checking the credentials!
  checkUserByIdPasswordStatus(idAdmin, adminPassword, status, (response) => {
    if(response.ok){
      //Clean all datas on collection 'Audios'
      Videos.deleteMany(
        {},
        (err, data) => {
          if(err){
            res.status(500).send(err);
          }else{
            res.status(200).send(data);
          }
        }
      );
    }else{
      res.status(404).send(response);
    }
  });
}

exports.loadDBOthers = (req, res) => {
  let {idAdmin}     = req.params,
      status        = 'admin',
      adminPassword = req.body.adminPassword;
	config.log('/accounts/admin/:idAdmin/load_db/videos', 'LOADING...DB');
	let dirname = './public/files',
		category = {videos:config.fextname.others};
  // Make safe operation checking the credentials!
  checkUserByIdPasswordStatus(idAdmin, adminPassword, status, (response) => {
    if(response.ok){
      // Calling the functions-recursive and set collection
      findFilesByCategory(
        dirname, 
        category, 
        (file) => {
          Others.create(
            {
              fpath: file.fpath,
              fname: file.fname, 
              fsize: file.fsize,
              fextname: file.fextname,
              fdirname: file.fdirname,
              fatime: file.fatime,
              fmtime: file.fmtime,
              fctime: file.fctime
            },
            (err, data) => {
              if(err){
                if(err.code === 11000){
                  config.log('E: DUPLICATE ***', err.keyValue);
                }else{
                  config.log('E:*** ', err);
                }
              }else{	// Success
                config.log('Added',data.fpath );
              }
            }
          )
        });
      res.status(200).send(response);
    }else{
      res.status(404).send(response);
    }
  })
	
}

exports.resetDBOthers = (req, res) => {
  let {idAdmin}     = req.params,
      status        = 'admin',
      adminPassword = req.body.adminPassword;
  config.log('/accounts/admin/:idAdmin/reset_db/others', 'RESETING... DB');
  // Make safe operation checking the credentials!
  checkUserByIdPasswordStatus(idAdmin,adminPassword, status, (response) => {
    if(response.ok){
      //Clean all datas on collection 'Audios'
      Others.deleteMany(
        {},
        (err, data) => {
          if(err){
            res.status(500).send(err);
          }else{
            res.status(200).send(data);
          }
        }
      );
    }else{
      res.status(404).send(response);
    }
  });
}

//app.post('/accounts/admin/:idAdmin/upload')
exports.upload = (req, res) => {
  let idAdmin = req.params.idAdmin;
  config.log("calling '/accounts/admin/:idAdmin/upload' req.files ", req.files,'***' ,req.body);
  // Make safe operation checking the credentials!
  checkUserByIdStatus(idAdmin, (response) => {
    if(response.ok){
      if(req.files === null){
        config.error('Error Upload!, no file selected');
        return res.status(400).json({msg:'No file uploaded'});
      }
      const file = req.files.file;
      let filename = req.body.description;
      // let uFilename = `${file.md5}-${filename.replaceAll(/\s/g, '-')}`;
      let uFilename = `${file.md5}`;
    
      //Save the UPLOAD
      let dirname = `${path.resolve('.')}/public/Uploads/${uFilename}`;
      file.mv(dirname, (err) => {
        if(err){
          console.error(err);
          return res.status(500).send(err);
        }
        return res.status(200).send(response);
      });    
    }else{
      res.status(404).send(response);
    }
  })
}

//app.post('/accounts/admin/:idAdmin/users_manager/:action')
exports.usersManager = (req, res) => {
  const idAdmin = req.params.idAdmin;
  let action = req.params.action;
  const user = req.body
  //config.log("app.post('/accounts/admin/:id/users_manager/:action'",action,'***', user); 
  checkUserByIdStatus(idAdmin, (response) => {
    if(response.ok){
      //Check :action request by USER
      if(action==='EDIT'){
        //Verify the authentication admin (password,status)
        checkUserByPasswordStatus(user.adminPassword, (response) => {
          if(response.ok){
            Users.updateOne(
              {_id: user._id},
              {
                email: user.email,
                phoneNumber: user.phoneNumber,
                password: user.password,
                status: user.status
              },
              (err, data) => {
                if(err){
                  if(err.code === 11000){
                    config.error('DUPLICATED', err.keyValue)
                  }
                  res.status(500).send(err);
                }else{
                  res.status(200).send();
                }
              }
            ) //END Users.updateOne()
          }else{
            res.status(404).send(response);
          }
        }); //END checkUserByPasswordStatus()
      }else if(action==='DELETE'){
        //Verify the authentication admin (password,status)
        checkUserByPasswordStatus(user.adminPassword, (response) => {
          if(response.ok){
            Users.deleteOne(
              {_id: user._id},
              (err, data) => {
                if(err){
                  res.status(500).send(err);
                }else{
                  if(data.deletedCount > 0){
                    res.status(200).send(data);
                  }else{
                    res.status(404).send(data);
                  }
                }
              }
            )
          }else{
            res.status(404).send(response);
          }
        })//END checkUserByPasswordStatus()
      }else{
        //By default return some users's field from db
        Users.find(
          {},
          'name gender email phoneNumber status',
          (err, data) => {
            if(err){
              res.status(500).send(data);
            }else{
              res.status(200).send(data);
            }
          }
        );
      } // END action=='ALL'
    }else{
      res.status(404).send(response);
    }
  }); //END checkUserByIdStatus()
}