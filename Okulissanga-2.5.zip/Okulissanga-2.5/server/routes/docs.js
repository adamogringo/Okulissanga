const mongoose = require('mongoose');

const Docs = mongoose.model('Docs');

exports.section = (req, res) => {
    Docs.find(
        {}
        ,(err, data)=> {
            if(err){
                console.log('E:***', err);
            }else{
                res.json(data);
            }
        }
    );
}