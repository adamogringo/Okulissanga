const mongoose = require('mongoose');

const Apps = mongoose.model('Apps');

exports.section = (req, res) => {
    Apps.find(
        {}
        ,(err, data)=> {
            if(err){
                console.log('E:***', err);
            }else{
                res.json(data);
            }
        })
}