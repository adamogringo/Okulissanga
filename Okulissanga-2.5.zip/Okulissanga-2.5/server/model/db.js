const mongoose = require('mongoose');

// Make connection to Database
const dbURI = "mongodb://localhost:27017/Okulissanga";
mongoose.connect(dbURI);

// Handler the events on setup db
mongoose.connection.on('connected', () => {
    console.log(`Connection sucessful to ${dbURI}`);
});

mongoose.connection.on('disconnected', () => {
    console.log(`Connection disconnected with ${dbURI}`);
});

mongoose.connection.on('error', (err) => {
    console.log(`Error with connection ${dbURI}:\n ${err}`);
});

process.on('SIGINT', () => {
    mongoose.connection.close(() => {
        console.log('Closing DB manually!');
        process.exit(0);
    });
});

/* ************************
    SCHEMA FILE
************************ */
const fileSchema = new mongoose.Schema({
    fpath: String,
    fname: {type: String, unique: true},
    fsize: Number,
    fextname: String,
    fdirname: String,
    fatime: Date,
    fmtime: Date,
    fctime: Date,
    ficone: String,
    fadded: {type: Date, default: Date.now()}
});
// Build model from this schema
mongoose.model('Apps', fileSchema);
mongoose.model('Docs', fileSchema);
mongoose.model('Audios', fileSchema);
mongoose.model('Pictures', fileSchema);
mongoose.model('Videos', fileSchema);
mongoose.model('Others', fileSchema);

const usersSchema = new mongoose.Schema({
    name: {type:String},
    email: {type:String, unique: true},
    phoneNumber: {type:String, unique: true},
    password: String,
    birthday: Date,
    gender: String,     //Optional
    location: String,
    jobs: String,       // Optional
    imgProfile: String, // Optional
    status: {type: String, default:'user'}  // don't required on signup
});
// Build the Schema above with the name Users
mongoose.model('Users', usersSchema);