const express = require('express')
    ,expressFileUpload = require('express-fileupload')
    ,morgan = require('morgan')
    ,bodyParser = require('body-parser')
    ,db = require('./model/db')
    ,routes = require('./routes')
    ,users = require('./routes/users')
    ,admin = require('./routes/admin')
    ,apps = require('./routes/apps')
    ,docs = require('./routes/docs')
    ,audios = require('./routes/audios')
    ,pictures = require('./routes/pictures')
    ,videos = require('./routes/videos')
    ,others = require('./routes/others')
    ,search = require('./routes/search.js')
    ,config = require('../client/src/lib/config')
    ;
    
const app = express();
const PORT = config.portServer;

// Midllewares for make avalaible  
app.use(morgan('common'));
app.use(bodyParser.json());
app.use('/public',express.static('./public'));
app.use(expressFileUpload());

//const uploadUserImage = multer({dest:'../client/public/imgs/static/users/images/'});
//app.use(uploadUserImage.single('image'));

/* *******************************************
                ROUTES
* ******************************************* */ 
// USERS - ROUTES
app.get('/tests', users.tests);
app.post('/accounts/signin', users.signIn); 
app.post('/accounts/signup', users.signUp);
app.post('/accounts/login/:idUser', users.login);   
app.post('/accounts/users/:idUser', users.user);             
app.post('/accounts/users/:idUser/check_id', users.checkId)   // Just for validate the ID
app.post('/accounts/users/:idUser/edit', users.userEdit);
app.post('/accounts/users/:idUser/edit/upload_image', users.uploadUserImage);

// ADMIN - ROUTES
app.post('/accounts/admin/login', admin.login)
app.post('/accounts/admin/:idAdmin', admin.home)
app.post('/accounts/admin/:idAdmin/check', admin.check);
app.get('/accounts/admin/:idAdmin/info', admin.info);
app.post('/accounts/admin/:idAdmin/load_db/apps', admin.loadDBApps);
app.post('/accounts/admin/:idAdmin/reset_db/apps', admin.resetDBApps);
app.post('/accounts/admin/:idAdmin/load_db/docs', admin.loadDBDocs);
app.post('/accounts/admin/:idAdmin/reset_db/docs', admin.resetDBDocs);
app.post('/accounts/admin/:idAdmin/load_db/audios', admin.loadDBAudios);
app.post('/accounts/admin/:idAdmin/reset_db/audios', admin.resetDBAudios);
app.post('/accounts/admin/:idAdmin/load_db/pictures', admin.loadDBPictures);
app.post('/accounts/admin/:idAdmin/reset_db/pictures', admin.resetDBPictures);
app.post('/accounts/admin/:idAdmin/load_db/videos', admin.loadDBVideos);
app.post('/accounts/admin/:idAdmin/reset_db/videos', admin.resetDBVideos);
app.post('/accounts/admin/:idAdmin/load_db/others', admin.loadDBOthers);
app.post('/accounts/admin/:idAdmin/reset_db/others', admin.resetDBOthers);
app.post('/accounts/admin/:idAdmin/users_manager/:action', admin.usersManager);
  //UPLOADS
app.post('/accounts/admin/:idAdmin/upload', admin.upload);

// CATEGORY  - routes like API
app.get('/api/apps', apps.section);
app.get('/api/pictures', pictures.section);
app.get('/api/audios', audios.section);
app.get('/api/videos', videos.section);
app.get('/api/docs', docs.section);
app.get('/api/others', others.section);
// Search - on all sections
app.get('/files/search/:fname', search.index);
app.get('/files/search/', search.empty);


app.listen(PORT, () => {
    let logInfo = `LOG-INFO: Case RESET de DB runCommands 'db.coll.ensureIndex({fname:'text'})'`
    config.log(`Server OKULISSANGA running on '${config.host}:${PORT}'`,logInfo);
})